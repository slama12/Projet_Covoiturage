<?php
include('connexion_SQL.php');

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['id'])) {
    echo "Vous devez être connecté pour gérer vos réservations.";
    exit;
}

$id_conducteur = $_SESSION['id'];

// Récupérer les trajets réservés par l'utilisateur
$query = "
    SELECT t.heure, t.date_trajet, t.ville1, t.ville2, r.statut_reservation, r.date_reservation 
    FROM reserve r
    JOIN trajets t ON r.id = t.num_trajet
    WHERE r.id_conducteur = $1
    ORDER BY r.date_reservation DESC
";
$result = pg_query_params($connexion, $query, array($id_conducteur)) or die(pg_last_error($connexion));
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion de mes réservations</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<h2>Gestion de mes réservations</h2>

<h3>Mes trajets réservés</h3>
<table border="1">
    <tr>
        <th>Heure de départ</th>
        <th>Date du trajet</th>
        <th>Ville de départ</th>
        <th>Ville d'arrivée</th>
        <th>Statut de la réservation</th>
        <th>Date de réservation</th>
    </tr>
    <?php while ($row = pg_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo htmlspecialchars($row['heure']); ?></td>
            <td><?php echo htmlspecialchars($row['date_trajet']); ?></td>
            <td><?php echo htmlspecialchars($row['ville1']); ?></td>
            <td><?php echo htmlspecialchars($row['ville2']); ?></td>
            <td><?php echo htmlspecialchars($row['statut_reservation']); ?></td>
            <td><?php echo htmlspecialchars($row['date_reservation']); ?></td>
        </tr>
    <?php } ?>
</table>

</body>
</html>

<?php
pg_close($connexion);
?>

