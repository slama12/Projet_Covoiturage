<?php
header('Content-Type: text/html; charset=UTF-8');
session_start();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Gestion des conducteurs</title>
</head>

<body>

<?php
// Récupérer la variable 'modif' depuis l'URL
$modif = isset($_GET['modif']) ? $_GET['modif'] : '';

// Inclure le fichier de connexion à la base de données
include('connexion_SQL.php');

// Récupérer les variables du formulaire en échappant les caractères spéciaux pour éviter les injections SQL
$pseudo = isset($_POST['pseudo']) ? pg_escape_string($connexion, htmlspecialchars($_POST['pseudo'])) : '';
$mail = isset($_POST['mail']) ? pg_escape_string($connexion, htmlspecialchars($_POST['mail'])) : '';
$mdp = isset($_POST['mdp']) ? pg_escape_string($connexion, htmlspecialchars($_POST['mdp'])) : '';
$nom = isset($_POST['nom']) ? pg_escape_string($connexion, htmlspecialchars($_POST['nom'])) : '';
$prenom = isset($_POST['prenom']) ? pg_escape_string($connexion, htmlspecialchars($_POST['prenom'])) : '';
$tel = isset($_POST['tel']) ? pg_escape_string($connexion, htmlspecialchars($_POST['tel'])) : '';

$date = date("Y-m-d");

// Vérifier si l'utilisateur est connecté et si une modification est demandée
if (isset($_SESSION['loginOK']) && $_SESSION['loginOK'] == true && $modif == 1) {
    $id = $_SESSION['id'];

    $update_query = "UPDATE conducteurs SET pseudo='$pseudo', mail='$mail', mdp='$mdp', nom='$nom', prenom='$prenom', tel='$tel' WHERE id_conducteur='$id' LIMIT 1";
    pg_query($connexion, $update_query) or die(pg_last_error($connexion));

    echo "<table width='940' border='0' align='left'>
            <tr>
                <td width='150' valign='top'>";
    include('frame_gauche.php');
    echo "</td>
                <td valign='top'>";
    if ($_SESSION['loginOK'] == true) {
        include('menus_session.htm');
        echo "</br>";
    }
    echo "Les modifications ont bien été prises en compte <br /><br /><br />";
    echo "<a href='index2.php'>Retour à l'accueil</a>";
    echo "</td></tr></table>";
} else {
    $reponse = pg_query($connexion, "SELECT * FROM conducteurs WHERE pseudo='$pseudo'") or die(pg_last_error($connexion));
    $donnees = pg_fetch_array($reponse);

    if (empty($donnees)) {
        echo "<table width='940' border='0' align='left'>
                <tr>
                    <td width='150' valign='top'>";
        include('frame_gauche.php');
        echo "</td>
                    <td valign='top'>";

        $insert_query = "INSERT INTO conducteurs (pseudo, mail, mdp, nom, prenom, tel) VALUES ('$pseudo', '$mail', '$mdp', '$nom', '$prenom', '$tel')";
        pg_query($connexion, $insert_query) or die(pg_last_error($connexion));

        $_SESSION['pseudo'] = $pseudo;
        $_SESSION['mail'] = $mail;
        $_SESSION['loginOK'] = true;

        $reponse = pg_query($connexion, "SELECT * FROM conducteurs WHERE pseudo='$pseudo'") or die(pg_last_error($connexion));
        while ($donnees = pg_fetch_array($reponse)) {
            $_SESSION['id'] = $donnees['id_conducteur'];
        }

        pg_close($connexion);

        $objet = "Votre inscription sur covoiturage";
        $message = "Bonjour,<br><br>Bienvenue sur le site covoiturage.<br><br>Voici vos informations personnelles:<br><br>pseudo : $pseudo<br>mot de passe : $mdp<br><br>L'équipe de <a href='http://vvcovoiturage.free.fr'>vvcovoiturage</a>";

        $headers = 'Content-Type: text/html; charset="iso-8859-1"' . "\r\n";
        $headers .= 'From: vvcovoiturage <no-reply@vvcovoiturage.free.fr>' . "\r\n";

        mail($mail, $objet, $message, $headers);

        include('menus_session.htm');
        echo "</br>";
        echo "Votre inscription a bien été prise en compte, merci. Vous êtes maintenant connecté.<br /><br /><br />";
        echo "Un mail vous a été envoyé avec vos informations personnelles.";
        echo "<br /><br />";
        echo "<a href='index2.php'>Retour à l'accueil</a>";
        echo "&nbsp;&nbsp;&nbsp;&nbsp;";
        echo "<a href='saisir_trajet.php'>Saisir un trajet</a>";
        echo "</td></tr></table>";
    } else {
        $modif = 2;
        $pseudo2 = $pseudo;
        include('saisir_donnees_perso.php');
        echo "<script>alert(unescape('Désolé, ce pseudo existe déjà !'))</script>";
    }
}
?>

</body>
</html>
