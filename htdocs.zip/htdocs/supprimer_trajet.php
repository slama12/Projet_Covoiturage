<?php

$num = $_GET['num_trajet'];
$id_session = $_SESSION['id'];

if (isset($_SESSION['loginOK']) && $_SESSION['loginOK'] == true) {

    include('connexion_SQL.php');

    // Vérifiez la connexion à la base de données
    if (!$connexion) {
        echo "<h3 style='color:red'>Erreur de connexion à la base de données</h3>";
        exit;
    }

    $reponse = pg_query($connexion, "SELECT * FROM trajets WHERE num_trajet='$num'") or die(pg_last_error($connexion));

    $id = null; // Initialisez $id avant de l'utiliser

    // On vérifie l'identité du créateur de la fiche :
    while ($donnees = pg_fetch_array($reponse)) {
        $id = $donnees['id_conducteur']; // Assurez-vous que cette colonne existe dans la table trajets
    }

    // Vérifiez si l'identifiant du trajet a été récupéré
    if ($id === null) {
        echo "<h3 style='color:red'>Trajet non trouvé</h3>";
        exit;
    }

    if ($id == $id_session) {
        $delete_result = pg_query($connexion, "DELETE FROM trajets WHERE num_trajet='$num'");

        if ($delete_result) {
            echo "</br>";
            echo "<h3 style='color:green'>Trajet supprimé avec succès !</h3>";
        } else {
            echo "<h3 style='color:red'>Erreur lors de la suppression du trajet</h3>";
            echo "</br>";
            echo "<a href=\"index.php?gestion_mes_trajets\">Retour à l'accueil</a>";
        }
    } else {
        echo "<h3 style='color:red'>Vous n'êtes pas autorisé à supprimer ce trajet</h3>";
        echo "</br>";
        echo "<a href=\"index.php?gestion_mes_trajets\">Retour à l'accueil</a>";
    }

} else {
    echo "Merci de vous identifier pour accéder à cette page";
}

pg_close($connexion);

?>

