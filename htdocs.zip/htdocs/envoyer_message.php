<?php
session_start();
require 'vendor/autoload.php'; // Assurez-vous que le chemin est correct

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_SESSION['loginOK']) && $_SESSION['loginOK'] == true) { 
    $id_exp = $_GET['id'];

    include('connexion_SQL.php');

    // Utilisation de pg_query_params pour les requêtes paramétrées
    $reponse = pg_query_params($connexion, "SELECT * FROM conducteurs WHERE id_conducteur=$1", array($id_exp));
    
    $mail_dest = '';
    while ($donnees = pg_fetch_array($reponse)) {
        $mail_dest = $donnees['mail'];
    }

    if ($mail_dest) {
        $de = pg_escape_string($connexion, htmlspecialchars($_POST['de']));
        $objet = pg_escape_string($connexion, htmlspecialchars($_POST['objet']));
        $message = pg_escape_string($connexion, htmlspecialchars($_POST['message']));

        $mail = new PHPMailer(true);

        try {
            // Configuration du serveur SMTP
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Remplacez par votre serveur SMTP
            $mail->SMTPAuth = true;
            $mail->Username = 'mohamed1482001@gmail.com'; // Remplacez par votre adresse email
            $mail->Password = 'aoki ywzx eehf kuhp'; // Remplacez par votre mot de passe
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Destinataire
            $mail->setFrom($de);
            $mail->addAddress($mail_dest);

            // Contenu de l'email
            $mail->isHTML(true);
            $mail->Subject = $objet;
            $mail->Body    = $message;

            $mail->send();
            echo "Le message a été envoyé";
        } catch (Exception $e) {
            echo "Erreur lors de l'envoi de l'email : {$mail->ErrorInfo}";
        }
    } else {
        echo "Erreur : Adresse email du destinataire introuvable.";
    }
    
    pg_close($connexion);
} else {
    echo "Merci de vous identifier pour accéder à cette page";
    include('index.php');
}
?>
