<?php
if (!isset($_SESSION)) {
    session_start();
}

$modif = isset($_GET['modif']) ? $_GET['modif'] : "";
$trajet2 = isset($_GET['num_traj']) ? $_GET['num_traj'] : "";

$id_cond = $_SESSION['id'];

include('connexion_SQL.php');

$ville1 = isset($_POST['ville1']) ? pg_escape_string($connexion, htmlspecialchars($_POST['ville1'])) : "";
$ville2 = isset($_POST['ville2']) ? pg_escape_string($connexion, htmlspecialchars($_POST['ville2'])) : "";
$date_trajet = isset($_POST['date_trajet']) ? pg_escape_string($connexion, htmlspecialchars($_POST['date_trajet'])) : "";
$heure = isset($_POST['heure']) ? pg_escape_string($connexion, htmlspecialchars($_POST['heure'])) : "";
$nbr_places = isset($_POST['nbr_places']) ? pg_escape_string($connexion, htmlspecialchars($_POST['nbr_places'])) : "";
$coment = isset($_POST['coment']) ? nl2br(pg_escape_string($connexion, htmlspecialchars($_POST['coment']))) : "";
$heure_retour = isset($_POST['heure_retour']) ? pg_escape_string($connexion, htmlspecialchars($_POST['heure_retour'])) : "";
$date_trajet_retour = isset($_POST['date_trajet_retour']) ? pg_escape_string($connexion, htmlspecialchars($_POST['date_trajet_retour'])) : "";
$type_trajet = isset($_POST['type_trajet']) ? pg_escape_string($connexion, htmlspecialchars($_POST['type_trajet'])) : "";

// Vérification que les champs date ne sont pas vides
if (empty($date_trajet)) {
    die("La date du trajet ne peut pas être vide.");
}

if ($_SESSION['loginOK'] == true && $modif == 1) { // S'il s'agit d'une modification
    $query = "
        UPDATE trajets 
        SET ville1 = '$ville1', ville2 = '$ville2', heure = '$heure', type_trajet = '$type_trajet', date_trajet = '$date_trajet', nbr_places = '$nbr_places', coment = '$coment' 
        WHERE num_trajet = '$trajet2' AND id_conducteur = '$id_cond'
    ";
    $result = pg_query($connexion, $query);
    if (!$result) {
        die("Erreur lors de la mise à jour : " . pg_last_error($connexion));
    }
    
    echo "<h4 style='color:green'>Les modifications ont bien été prises en compte</h4><br /><br />";
} else { // Pour un nouveau trajet
    $query = "
        SELECT * FROM trajets 
        WHERE id_conducteur = '$id_cond' AND ville1 = '$ville1' AND ville2 = '$ville2' AND heure = '$heure' AND type_trajet = '$type_trajet' AND date_trajet = '$date_trajet'
    ";
    $result = pg_query($connexion, $query);
    if (!$result) {
        die("Erreur lors de la vérification des trajets existants : " . pg_last_error($connexion));
    }
    
    $i = pg_num_rows($result);
    
    if ($i == 0) {
        $insert_query = "
            INSERT INTO trajets (id_conducteur, ville1, ville2, heure, type_trajet, date_trajet, nbr_places, coment) 
            VALUES ('$id_cond', '$ville1', '$ville2', '$heure', '$type_trajet', '$date_trajet', '$nbr_places', '$coment')
        ";
        $result_insert = pg_query($connexion, $insert_query);
        if (!$result_insert) {
            die("Erreur lors de l'insertion du trajet : " . pg_last_error($connexion));
        }
        
        if (!empty($heure_retour) && !empty($date_trajet_retour)) {
            $insert_return_query = "
                INSERT INTO trajets (id_conducteur, ville1, ville2, heure, type_trajet, date_trajet, nbr_places, coment) 
                VALUES ('$id_cond', '$ville2', '$ville1', '$heure_retour', '$type_trajet', '$date_trajet_retour', '$nbr_places', '$coment')
            ";
            $result_return_insert = pg_query($connexion, $insert_return_query);
            if (!$result_return_insert) {
                die("Erreur lors de l'insertion du trajet de retour : " . pg_last_error($connexion));
            }
        }
        
        echo "<h4 style='color:green'>Votre trajet a bien été enregistré, merci.</h4><br />";
    } else {
        echo "<h4 style='color:red'>Ce trajet est déjà saisi sous votre nom !</h4><br />";
    }
}

pg_close($connexion);
?>

