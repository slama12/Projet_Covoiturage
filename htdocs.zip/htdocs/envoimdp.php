<?php
session_start();
require 'vendor/autoload.php'; // Assurez-vous que le chemin est correct

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Envoyer mot de passe</title>
</head>
<body>
<table width="930" border="0" align="left">
    <tr>
        <td width="160" valign="top">
            <?php include('frame_gauche.php'); ?>
        </td>
        <td width="770" valign="top">
            <?php
            include('connexion_SQL.php');

            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])) {
                $email = pg_escape_string($connexion, htmlspecialchars($_POST['email']));

                $reponse = pg_query($connexion, "SELECT * FROM conducteurs WHERE mail='$email'");
                if (!$reponse) {
                    echo "Erreur lors de l'exécution de la requête: " . pg_last_error($connexion);
                    exit;
                }

                $donnees = pg_fetch_array($reponse);

                if ($donnees == false) {
                    echo "<br><br><br><br>Désolé, cet email n'est pas enregistré sur covoiturage, "; ?> 
                    <a href="oublimdp.php" target="bas">réessayer</a> 
                    <?php
                } else {
                    $pseudo_oubli = $donnees['pseudo'];
                    $pwd_oubli = $donnees['mdp'];

                    $mail = new PHPMailer(true);
                    try {
                        // Configuration du serveur SMTP
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true;
                        $mail->Username = 'mohamed1482001@gmail.com'; // Remplacez par votre adresse email
                        $mail->Password = 'aoki ywzx eehf kuhp'; // Remplacez par votre mot de passe
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                        $mail->Port = 587;

                        // Destinataire
                        $mail->setFrom('no-reply@vvcovoiturage.free.fr', 'VVCovoiturage');
                        $mail->addAddress($email);

                        // Contenu de l'email
                        $mail->isHTML(true);
                        $mail->Subject = 'Votre mot de passe';
                        $mail->Body    = "Bonjour,<br><br>Voici vos informations personnelles:<br><br>Pseudo : " . $pseudo_oubli . "<br>Mot de passe : " . $pwd_oubli . "<br><br>L'équipe de <a href=\"http://vvcovoiturage.free.fr\">vvcovoiturage</a>";

                        $mail->send();
                        echo "<br>Vos informations personnelles ont été envoyées sur votre adresse email.";
                    } catch (Exception $e) {
                        echo "<br>Erreur lors de l'envoi de l'email : {$mail->ErrorInfo}";
                    }
                }
            } else {
                echo "Aucune adresse email fournie.";
            }

            if (isset($connexion) && is_resource($connexion)) {
                pg_close($connexion);
            }
            ?>
        </td>
    </tr>
</table>
</body>
</html>
