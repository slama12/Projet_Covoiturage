<?php
$ville1 = "";
$ville2 = "";
$heure = "tous";

include('connexion_SQL.php');

if (isset($_POST['ville1'])) {
    $ville1 = pg_escape_string($connexion, htmlspecialchars($_POST['ville1']));
}
if (isset($_POST['ville2'])) {
    $ville2 = pg_escape_string($connexion, htmlspecialchars($_POST['ville2']));
}
if (isset($_POST['heure'])) {
    $heure = pg_escape_string($connexion, htmlspecialchars($_POST['heure']));
}

if ($ville1 == "") {
    $ville1 = "peu importe";
}
if ($ville2 == "") {
    $ville2 = "peu importe";
}

$depart = $ville1;
$arrivee = $ville2;
$heure_rech = $heure;

if ($ville1 == "peu importe") {
    $ville1 = "";
}
if ($ville2 == "peu importe") {
    $ville2 = "";
}

if ($heure == "tous") {
    $heure1 = "00:00:00";
    $heure2 = "23:59:59";
} else {
    $heure_ex = explode(":", $heure);

    if ($heure_ex[0] != "00") {
        $h1 = $heure_ex[0] - 1;
    } else {
        $h1 = $heure_ex[0];
    }
    if ($heure_ex[0] < 11 && $heure_ex[0] != "00") {
        $h1 = "0" . $h1;
    }

    $h2 = $heure_ex[0] + 1;
    if ($heure_ex[0] < 9) {
        $h2 = "0" . $h2;
    }

    if ($heure_ex[1] == 30) {
        $heure1 = $heure_ex[0] . ":00:00";
        $heure2 = $h2 . ":00:00";
    } else {
        $heure1 = $h1 . ":30:00";
        $heure2 = $heure_ex[0] . ":30:00";
    }
}

$retour = pg_query($connexion, "SELECT COUNT(*) AS nbre_entrees FROM trajets WHERE ((heure >= '$heure1' AND heure <= '$heure2') OR is_variable = TRUE) AND ville1 LIKE '%$ville1%' AND ville2 LIKE '%$ville2%' ");
if (!$retour) {
    echo "Erreur dans l'exécution de la requête: " . pg_last_error($connexion);
    exit;
}
$donnees_compt = pg_fetch_array($retour);
$i = $donnees_compt['nbre_entrees'];

$reponse = pg_query($connexion, "SELECT * FROM trajets WHERE ((heure >= '$heure1' AND heure <= '$heure2') OR is_variable = TRUE) AND ville1 LIKE '%$ville1%' AND ville2 LIKE '%$ville2%' ");
if (!$reponse) {
    echo "Erreur dans l'exécution de la requête: " . pg_last_error($connexion);
    exit;
}

if ($i == 0) {
    echo "&nbsp;Désolé, aucun trajet ne correspond à votre recherche";
    echo "</br></br>";
} else {
    echo "<br>";
    echo "Il y a <strong>" . $i . " trajet(s)</strong> correspondants entre " . htmlspecialchars($heure1) . " et " . htmlspecialchars($heure2);
    echo "<br>";
    ?>
    <table class="tablezied" cellspacing="0">
        <tr>
            <th>Ville de départ</th>
            <th>Ville d'arrivée</th>
            <th>Heure de départ</th>
            <th>Voir les détails</th>
            <th>Réserver</th>
        </tr><!-- Table Header -->
        <?php
        $i = 0;
        while ($donnees = pg_fetch_array($reponse)) {
            $num_T = htmlspecialchars($donnees['num_trajet']);
            $ident = htmlspecialchars($donnees['id']);
            $ville1_tb = htmlspecialchars($donnees['ville1']);
            $ville2_tb = htmlspecialchars($donnees['ville2']);
            $heure_tb = htmlspecialchars($donnees['heure']);
            $type_trajet = htmlspecialchars($donnees['type_trajet']);

            if ($i % 2 == 0) {
                echo "<tr>";
            } else {
                echo "<tr class='even'>";
            }
            echo "<td> $ville1_tb </td>";
            echo "<td> $ville2_tb </td>";
            echo "<td> $heure_tb </td>";
            echo "<td> $type_trajet";
            if ($type_trajet == "ponctuel") {
                $type_trajet;
            }
            echo " </td>";
            echo "<td><a href=\"index.php?detail_projet&num_trajet=$num_T\">Voir les détails</a></td>";
            echo "<td><a href=\"reserve.php?num_trajet=$num_T\" class=\"styled-button-12\">Réserver</a></td>";
            echo "</tr>";
            $i++;
        }
        echo "</table>";
}
pg_close($connexion);
?>
<br><hr>
<?php
if ($ville1 != "" || $ville2 != "") {
    ?>    
    <strong>&nbsp;&nbsp;Résultats sur les autres sites de covoiturage :</strong>
    <br><br>
    &nbsp;<a href="http://www.123envoiture.com/recherche-resultats.php?recherche=rapide&ville_depart=<?php echo htmlspecialchars($ville1); ?>&ville_arrivee=<?php echo htmlspecialchars($ville2); ?>&status=tous" target="_blank">123envoiture</a>
    <?php
    if ($ville1 != "" && $ville2 != "") {
        ?>
        <br><br>    
        &nbsp;<a href="http://www.easycovoiturage.com/covoiturage/covoiturage_page/page.php?source=index&adr_from=<?php echo htmlspecialchars($ville1); ?>&elarg_dep=0&adr_to=<?php echo htmlspecialchars($ville2); ?>&elarg_arr=0&conpass=CP&date_trajet=jj/mm/aaaa%20&date_elarg=0" target="_blank">Easy Covoiturage</a>
        <?php
    }
    ?>
    <br><br>    
    <form name='recherche' action="http://www.tribu-covoiturage.com/recherche.php" method="POST">
        <input type="hidden" value="<?php echo htmlspecialchars($ville1); ?>" name="DVille" id="DVille">
        <input type="hidden" value="<?php echo htmlspecialchars($ville2); ?>" name="AVille" id="AVille">
        &nbsp;<a href="#" onclick="document.recherche.submit();">Tribu covoiturage</a>
    </form> 
    <?php
}
?>
