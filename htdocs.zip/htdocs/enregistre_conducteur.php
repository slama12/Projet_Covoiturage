<?php
header('Content-Type: text/html; charset=UTF-8');
session_start();
?>

<html>
<head>
    <title>Enregistrer Conducteur</title>
</head>
<body>
<?php
require 'vendor/autoload.php'; // Assurez-vous que le chemin est correct

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$modif = isset($_GET['modif']) ? $_GET['modif'] : '';

include('connexion_SQL.php');

$pseudo = isset($_POST['pseudo']) ? pg_escape_string($connexion, htmlspecialchars($_POST['pseudo'])) : '';
$mail_user = isset($_POST['mail']) ? pg_escape_string($connexion, htmlspecialchars($_POST['mail'])) : '';
$mdp = isset($_POST['pwd']) ? pg_escape_string($connexion, htmlspecialchars($_POST['pwd'])) : '';

if (empty($pseudo) || empty($mail_user) || empty($mdp)) {
    echo "Pseudo, mail et mot de passe sont requis.";
    exit;
}

$nom = pg_escape_string($connexion, htmlspecialchars($_POST['nom']));
if ($nom == "nom") { $nom = ""; }

$prenom = pg_escape_string($connexion, htmlspecialchars($_POST['prenom']));
if ($prenom == "prenom") { $prenom = ""; }

$tel = pg_escape_string($connexion, htmlspecialchars($_POST['tel']));

$date = date("Y-m-d");

echo "Debug: pseudo = $pseudo, mail = $mail_user, mdp = $mdp"; // Message de débogage

if (isset($_SESSION['loginOK']) && $_SESSION['loginOK'] == true && $modif == 1) {
    $id = $_SESSION['id'];

    $query = "UPDATE conducteurs SET pseudo='$pseudo', mail='$mail_user', mdp='$mdp', nom='$nom', prenom='$prenom', tel='$tel' WHERE id_conducteur='$id' LIMIT 1";
    pg_query($connexion, $query) or die(pg_last_error($connexion));

    echo "<table width='940' border='0' align='left'>";
    echo "<tr><td width='150' valign='top'>";
    include('frame_gauche.php');
    echo "</td><td valign='top'>";
    if ($_SESSION['loginOK'] == true) {
        include('menus_session.htm');
        echo "</br>";
    }
    echo "Les modifications ont bien été prises en compte <br /><br /><br />";
    echo "<a href=\"index2.php\">Retour à l'accueil</a>";
    echo "</td></tr></table>";
} else {
    $reponse = pg_query($connexion, "SELECT * FROM conducteurs WHERE pseudo='$pseudo'") or die(pg_last_error($connexion));

    $donnees = pg_fetch_array($reponse);

    if ($donnees == "") {
        echo "<table width='940' border='0' align='left'>";
        echo "<tr><td width='150' valign='top'>";
        include('frame_gauche.php');
        echo "</td><td valign='top'>";
        
        $query = "INSERT INTO conducteurs (pseudo, mail, mdp, nom, prenom, tel) VALUES ('$pseudo', '$mail_user', '$mdp', '$nom', '$prenom', '$tel')";
        echo "Debug: Query = $query"; // Message de débogage
        pg_query($connexion, $query) or die(pg_last_error($connexion));

        $_SESSION['pseudo'] = $pseudo;
        $_SESSION['mail'] = $mail_user;
        $_SESSION['loginOK'] = true;

        $reponse = pg_query($connexion, "SELECT * FROM conducteurs WHERE pseudo='$pseudo'") or die(pg_last_error($connexion));

        while ($donnees = pg_fetch_array($reponse)) {
            $_SESSION['id'] = $donnees['id_conducteur'];
        }

        pg_close($connexion);

        // Utiliser PHPMailer pour envoyer l'email
        $mail = new PHPMailer(true);
        try {
            // Configuration du serveur
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mohamed1482001@gmail.com';
            $mail->Password = 'aoki ywzx eehf kuhp'; // Utilisez le mot de passe d'application généré ici
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Destinataires
            $mail->setFrom('mohamed1482001@gmail.com', 'VVCovoiturage');
            $mail->addAddress($mail_user); // Passer l'adresse email du destinataire correctement

            // Contenu de l'email
            $mail->isHTML(true);
            $mail->Subject = 'Votre inscription sur covoiturage';
            $mail->Body = "Bonjour,<br><br>Bienvenue sur le site covoiturage.<br><br>Voici vos informations personnelles:<br><br>pseudo : " . $pseudo . "<br>mot de passe : " . $mdp . "<br><br>L'équipe de <a href=\"http://vvcovoiturage.free.fr\">vvcovoiturage</a>";

            $mail->send();
            echo 'Votre inscription a bien été prise en compte, merci. Vous êtes maintenant connecté.<br /><br /><br />';
            echo 'Un mail vous a été envoyé avec vos informations personnelles.';
        } catch (Exception $e) {
            echo "L'email n'a pas pu être envoyé. Erreur: {$mail->ErrorInfo}";
        }

        include('menus_session.htm');
        echo "</br>";

        echo "<a href=\"index2.php\">Retour à l'accueil</a>";
        echo "&nbsp;&nbsp;&nbsp;&nbsp;";
        echo "<a href=\"saisir_trajet.php\">Saisir un trajet</a>";
        echo "</td></tr></table>";
    } else {
        $modif = 2;
        $pseudo2 = $pseudo;
        include('saisir_donnees_perso.php');
        echo "<script>alert(unescape('D%E9sol%E9, ce pseudo existe d%E9j%E0 !'))</script>";
    }
}
?>
</body>
</html>





