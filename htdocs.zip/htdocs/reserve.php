<?php
session_start();
include('connexion_SQL.php');
require 'vendor/autoload.php'; // Assurez-vous que le chemin est correct

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['loginOK']) || $_SESSION['loginOK'] !== true) {
    echo "Merci de vous identifier pour accéder à cette page.<br>";
    echo "<a href='login.php'>Se connecter</a><br>";
    echo "Vous n'êtes pas inscrits? <a href='saisir_donnees_perso.php'>Formulaire d'inscription</a>";
    exit;
}

if (!isset($_GET['num_trajet']) || empty($_GET['num_trajet'])) {
    echo "Erreur: Aucun trajet spécifié.";
    exit;
}

$num_trajet = pg_escape_string($connexion, htmlspecialchars($_GET['num_trajet']));

// Récupérer les informations du trajet
$query = "SELECT * FROM trajets WHERE num_trajet = '$num_trajet'";
$result = pg_query($connexion, $query);

if (!$result) {
    echo "Erreur lors de la récupération du trajet: " . pg_last_error($connexion);
    exit;
}

if (pg_num_rows($result) == 0) {
    echo "Erreur: Trajet non trouvé.";
    exit;
}

$trajet = pg_fetch_array($result);
$ville1 = htmlspecialchars($trajet['ville1']);
$ville2 = htmlspecialchars($trajet['ville2']);
$heure_depart = htmlspecialchars($trajet['heure']);
$date_depart = htmlspecialchars($trajet['date_trajet']);
$places_disponibles = (int) htmlspecialchars($trajet['nbr_places']);
$lieu_rendezvous = htmlspecialchars($trajet['coment']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_conducteur = $_SESSION['id']; // Récupérer l'ID de l'utilisateur connecté depuis la session
    
    // Vérifier s'il reste des places disponibles
    if ($places_disponibles <= 0) {
        echo "Désolé, il n'y a plus de places disponibles pour ce trajet.";
        exit;
    }
    
    // Vérifier si la réservation existe déjà
    $check_query = "SELECT * FROM reserve WHERE id_conducteur = '$id_conducteur' AND id = '$num_trajet'";
    $check_result = pg_query($connexion, $check_query);

    if (!$check_result) {
        echo "Erreur lors de la vérification de la réservation: " . pg_last_error($connexion);
        exit;
    }

    if (pg_num_rows($check_result) > 0) {
        echo "Vous avez déjà réservé ce trajet.";
        exit;
    }

    $date_reservation = date('Y-m-d'); // Date actuelle
    $statut_reservation = 'confirmée'; // Statut par défaut

    // Commencer une transaction
    pg_query($connexion, "BEGIN");

    // Insertion de la réservation dans la base de données
    $insert_query = "INSERT INTO reserve (id_conducteur, id, statut_reservation, date_reservation) VALUES ('$id_conducteur', '$num_trajet', '$statut_reservation', '$date_reservation')";
    $insert_result = pg_query($connexion, $insert_query);

    if (!$insert_result) {
        pg_query($connexion, "ROLLBACK");
        echo "Erreur lors de l'insertion de la réservation: " . pg_last_error($connexion);
        exit;
    }

    // Mettre à jour le nombre de places disponibles
    $new_places_disponibles = $places_disponibles - 1;
    $update_query = "UPDATE trajets SET nbr_places = '$new_places_disponibles' WHERE num_trajet = '$num_trajet'";
    $update_result = pg_query($connexion, $update_query);

    if (!$update_result) {
        pg_query($connexion, "ROLLBACK");
        echo "Erreur lors de la mise à jour des places disponibles: " . pg_last_error($connexion);
        exit;
    }

    // Commit la transaction
    pg_query($connexion, "COMMIT");

    // Envoyer un email de confirmation
    $mail = new PHPMailer(true);
    try {
        // Configuration du serveur
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'mohamed1482001@gmail.com';
        $mail->Password = 'aoki ywzx eehf kuhp'; // Utilisez le mot de passe d'application généré ici
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Récupérer l'email du conducteur
        $conducteur_query = "SELECT mail FROM conducteurs WHERE id_conducteur = '$id_conducteur'";
        $conducteur_result = pg_query($connexion, $conducteur_query);
        $conducteur = pg_fetch_array($conducteur_result);
        $mail_conducteur = htmlspecialchars($conducteur['mail']);

        // Destinataires
        $mail->setFrom('votre.email@gmail.com', 'VVCovoiturage');
        $mail->addAddress($mail_conducteur); // Adresse email du conducteur

        // Contenu de l'email
        $mail->isHTML(true);
        $mail->Subject = 'Confirmation de réservation';
        $mail->Body = "Bonjour,<br><br>Votre réservation a été confirmée.<br><br>Voici les détails du trajet:<br><br>Ville de départ : $ville1<br>Ville d'arrivée : $ville2<br>Heure de départ : $heure_depart<br>Date de départ : $date_depart<br>Lieu de rendez-vous : $lieu_rendezvous<br><br>L'équipe de VVCovoiturage.";

        $mail->send();
        echo 'Votre réservation a été effectuée avec succès ! Un email de confirmation vous a été envoyé.';
    } catch (Exception $e) {
        echo "L'email n'a pas pu être envoyé. Erreur: {$mail->ErrorInfo}";
    }

    exit;
}

pg_close($connexion);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Réservation de trajet</title>
    <style>
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
        }
        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            box-sizing: border-box;
        }
        .btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Réservation de trajet</h1>
    <h2>Trajet sélectionné</h2>
    <p><strong>Ville de départ:</strong> <?php echo $ville1; ?></p>
    <p><strong>Ville d'arrivée:</strong> <?php echo $ville2; ?></p>
    <p><strong>Heure de départ:</strong> <?php echo $heure_depart; ?></p>
    <p><strong>Date de départ:</strong> <?php echo $date_depart; ?></p>
    <p><strong>Places disponibles:</strong> <?php echo $places_disponibles; ?></p>
    <p><strong>Lieu de rendez-vous:</strong> <?php echo $lieu_rendezvous; ?></p>

    <h2>Formulaire de réservation</h2>
    <form method="POST" action="">
        <div class="form-group">
            <label for="id_conducteur">ID Conducteur:</label>
            <input type="number" id="id_conducteur" name="id_conducteur" required>
        </div>
        <button type="submit" class="btn">Réserver</button>
    </form>
</body>
</html>

