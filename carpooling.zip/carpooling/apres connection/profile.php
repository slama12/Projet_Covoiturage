<?php
session_start();
include '../db/db_connect.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

$id_utilisateur = $_SESSION['id_utilisateur'];

// Retrieve user information
$query = "SELECT * FROM Utilisateur WHERE ID_Utilisateur = $1";
$result = pg_query_params($dbconn, $query, array($id_utilisateur));
$user = pg_fetch_assoc($result);

// Retrieve user's vehicle information from the Conduit table
$vehicle_query = "SELECT v.* FROM Vehicule v
                  JOIN Conduit c ON v.ID_Vehicule = c.ID_Vehicule
                  WHERE c.ID_Utilisateur = $1";
$vehicle_result = pg_query_params($dbconn, $vehicle_query, array($id_utilisateur));
$vehicles = pg_fetch_all($vehicle_result);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["update"])) {
    $nom = pg_escape_string($dbconn, $_POST['nom']);
    $prenom = pg_escape_string($dbconn, $_POST['prenom']);
    $email = pg_escape_string($dbconn, $_POST['email']);
    $phone = pg_escape_string($dbconn, $_POST['phone']);

    // Update user information
    $query = "UPDATE Utilisateur SET Nom_Utilisateur = $1, Prenom_Utilisateur = $2, Adresse_EMail = $3, Numero_Telephone = $4 WHERE ID_Utilisateur = $5";
    $result = pg_query_params($dbconn, $query, array($nom, $prenom, $email, $phone, $id_utilisateur));

    if ($result) {
        // Update session variables
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;
        $_SESSION['email'] = $email;
        $_SESSION['phone'] = $phone;
        echo "<script>alert('Les informations ont été mises à jour avec succès.'); window.location.href='profile.php';</script>";
    } else {
        echo "<script>alert('Erreur lors de la mise à jour : " . pg_last_error($dbconn) . "');</script>";
    }
}

pg_close($dbconn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Mon Profil</h2>
                <p>Vous pouvez mettre à jour vos informations ici.</p>
            </header>
            <div class="tabs">
                <button class="tab active" onclick="openTab(event, 'personal-info')">Information Personnelle</button>
                <button class="tab" onclick="openTab(event, 'vehicle-info')">Véhicule</button>
            </div>
            <div id="personal-info" class="tab-content active">
                <form action="profile.php" method="POST">
                    <div class="field-set">
                        <span class="input-item">
                            <i class="fa fa-user"></i>
                        </span>
                        <input class="form-input" name="nom" type="text" placeholder="Nom" value="<?php echo htmlspecialchars($user['nom_utilisateur']); ?>" required>
                        <br>
                        <span class="input-item">
                            <i class="fa fa-user"></i>
                        </span>
                        <input class="form-input" name="prenom" type="text" placeholder="Prénom" value="<?php echo htmlspecialchars($user['prenom_utilisateur']); ?>" required>
                        <br>
                        <span class="input-item">
                            <i class="fa fa-envelope"></i>
                        </span>
                        <input class="form-input" name="email" type="email" placeholder="Email" value="<?php echo htmlspecialchars($user['adresse_email']); ?>" required>
                        <br>
                        <span class="input-item">
                            <i class="fa fa-phone"></i>
                        </span>
                        <input class="form-input" name="phone" type="text" placeholder="Téléphone" value="<?php echo htmlspecialchars($user['numero_telephone']); ?>" required>
                        <br>
                        <button class="submit-button" type="submit" name="update">Mettre à jour</button>
                    </div>
                </form>
            </div>
            <div id="vehicle-info" class="tab-content">
                <h3>Véhicule</h3>
                <?php if (!empty($vehicles)): ?>
                    <ul>
                        <?php foreach ($vehicles as $vehicle): ?>
                            <li class="aff">
                                <p>Marque: <?= htmlspecialchars($vehicle['marque']) ?></p>
                                <p>Modèle: <?= htmlspecialchars($vehicle['modele']) ?></p>
                                <p>Année: <?= htmlspecialchars($vehicle['annee']) ?></p>
                                <p>Couleur: <?= htmlspecialchars($vehicle['couleur']) ?></p>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <form action="submit_vehicle_choice.php" method="POST">
                        <button class="submit-button" type="submit" name="use_existing_vehicle">Utiliser ce véhicule</button>
                        <button class="submit-button" type="submit" name="add_new_vehicle">Ajouter un nouveau véhicule</button>
                    </form>
                <?php else: ?>
                    <p>Vous n'avez enregistré aucun véhicule.</p>
                    <form action="submit_vehicle_choice.php" method="POST">
                        <button class="submit-button" type="submit" name="add_new_vehicle">Ajouter un nouveau véhicule</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function openTab(evt, tabId) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            tablinks = document.getElementsByClassName("tab");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            document.getElementById(tabId).classList.add("active");
            evt.currentTarget.classList.add("active");
        }
    </script>
</body>
</html>
