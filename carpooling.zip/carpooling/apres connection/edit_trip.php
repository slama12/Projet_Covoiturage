<?php
session_start();
include '../db/db_connect.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html");
    exit();
}

$id_utilisateur = $_SESSION['id_utilisateur'];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id_trajet'])) {
    $id_trajet = $_GET['id_trajet'];

    // Get trip information
    $trip_query = "SELECT * FROM Trajet WHERE ID_Trajet = $1 AND ID_Utilisateur = $2";
    $trip_result = pg_query_params($dbconn, $trip_query, array($id_trajet, $id_utilisateur));
    $trip = pg_fetch_assoc($trip_result);

    if ($trip) {
        // Get all stops
        $stops_query = "SELECT ar.adresse_arret, ar.CP_ville, ar.Details, ar.num_Arret 
                        FROM Comprend co 
                        JOIN Arret ar ON co.adresse_arret = ar.adresse_arret 
                        WHERE co.ID_Trajet = $1 ORDER BY ar.num_Arret ASC";
        $stops_result = pg_query_params($dbconn, $stops_query, array($id_trajet));
        $stops = pg_fetch_all($stops_result);

        if (!$stops) {
            echo "<script>alert('Erreur: impossible de récupérer les arrêts.'); window.history.back();</script>";
            exit();
        }
    } else {
        echo "<script>alert('Erreur: Trajet non trouvé ou vous n\'êtes pas autorisé à le modifier.'); window.history.back();</script>";
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $id_trajet = $_POST['id_trajet'];
    $ville_depart = $_POST['ville_depart'];
    $ville_destination = $_POST['ville_destination'];
    $date_trajet = $_POST['date_trajet'];
    $heure_depart = $_POST['heure_depart'];
    $places_disponibles = $_POST['places_disponibles'];

    // Begin transaction
    pg_query($dbconn, "BEGIN");

    // Update trip information
    $update_trip_query = "UPDATE Trajet SET ville_depart = $1, ville_destination = $2, date_trajet = $3, heure_depart = $4, places_disponibles = $5 WHERE ID_Trajet = $6 AND ID_Utilisateur = $7";
    $update_trip_result = pg_query_params($dbconn, $update_trip_query, array($ville_depart, $ville_destination, $date_trajet, $heure_depart, $places_disponibles, $id_trajet, $id_utilisateur));

    if ($update_trip_result) {
        // Commit transaction
        pg_query($dbconn, "COMMIT");
        echo "<script>alert('Trajet mis à jour avec succès.'); window.location.href='trajets.php';</script>";
    } else {
        // Rollback transaction
        pg_query($dbconn, "ROLLBACK");
        echo "<script>alert('Erreur lors de la mise à jour du trajet : " . pg_last_error($dbconn) . "');</script>";
    }
}

pg_close($dbconn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modifier Trajet</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function() {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>
    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Modifier Trajet</h2>
            </header>
            <?php if (!empty($trip)): ?>
            <form action="edit_trip.php" method="POST" class="field-set">
                <input type="hidden" name="id_trajet" value="<?= htmlspecialchars($trip['id_trajet']) ?>">
                <span class="input-item">
                    <i class="fa fa-map-marker-alt"></i>
                </span>
                <input class="form-input" type="text" name="ville_depart" value="<?= htmlspecialchars($trip['ville_depart'] ?? '') ?>" placeholder="Ville de Départ" required><br>

                <span class="input-item">
                    <i class="fa fa-map-marker-alt"></i>
                </span>
                <input class="form-input" type="text" name="ville_destination" value="<?= htmlspecialchars($trip['ville_destination'] ?? '') ?>" placeholder="Ville de Destination" required><br>
                
                <span class="input-item">
                    <i class="fa fa-calendar-alt"></i>
                </span>
                <input class="form-input" type="date" name="date_trajet" value="<?= htmlspecialchars($trip['date_trajet'] ?? '') ?>" required><br>

                <span class="input-item">
                    <i class="fa fa-clock"></i>
                </span>
                <input class="form-input" type="time" name="heure_depart" value="<?= htmlspecialchars($trip['heure_depart'] ?? '') ?>" required><br>

                <span class="input-item">
                    <i class="fa fa-users"></i>
                </span>
                <input class="form-input" type="number" name="places_disponibles" value="<?= htmlspecialchars($trip['places_disponibles'] ?? '') ?>" placeholder="Places Disponibles" required><br>

                <button class="submit-button" type="submit" name="update">Mettre à jour</button>
            </form>
            <form action="modify_stops.php" method="GET" class="field-set">
                <input type="hidden" name="id_trajet" value="<?= htmlspecialchars($trip['id_trajet']) ?>">
                <button class="submit-button" type="submit">Modifier les arrêts</button>
            </form>
            <?php else: ?>
                <p>Erreur: Trajet non trouvé ou vous n'êtes pas autorisé à le modifier.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
