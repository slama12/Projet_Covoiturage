<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_trajet'])) {
    $id_trajet = $_POST['id_trajet'];
    $user_id = $_SESSION['id_utilisateur'];
    $note = $_POST['note'];
    $commentaire = $_POST['commentaire'];

    // Insert the review into the Avis table
    $avis_query = "INSERT INTO Avis (date_avis, Note, Commentaire, ID_Trajet, ID_Utilisateur_CIR) VALUES (CURRENT_TIMESTAMP, $1, $2, $3, $4)";
    $result = pg_query_params($dbconn, $avis_query, array($note, $commentaire, $id_trajet, $user_id));

    if ($result) {
        echo "Avis soumis avec succès!";
        header("Location: trajets.php");
        exit();
    } else {
        echo "Erreur lors de la soumission de l'avis: " . pg_last_error($dbconn);
    }
}
?>
