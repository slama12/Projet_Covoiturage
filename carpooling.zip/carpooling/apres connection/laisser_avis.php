<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_trajet'])) {
    $id_trajet = $_POST['id_trajet'];
    $user_id = $_SESSION['id_utilisateur'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laisser un Avis</title>
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Laisser un Avis</h2>
                <p>Veuillez évaluer votre expérience.</p>
            </header>
            <form action="soumettre_avis.php" method="POST" class="field-set">
                <input type="hidden" name="id_trajet" value="<?= $id_trajet ?>">
                
                <span class="input-item">
                    <i class="fa fa-star"></i>
                </span>
                <input class="form-input" type="number" id="note" name="note" min="1" max="5" placeholder="Note (1-5)" required><br>
                <br>
                <span class="input-item">
                    <i class="fa fa-comment"></i>
                </span>
                <textarea class="form-input" id="commentaire" name="commentaire" placeholder="Commentaire" required></textarea><br>
                <br>
                <button class="submit-button" type="submit">Soumettre</button>
            </form>
        </div>
    </div>
</body>
</html>
