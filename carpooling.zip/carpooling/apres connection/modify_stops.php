<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

$id_utilisateur = $_SESSION['id_utilisateur'];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id_trajet'])) {
    $id_trajet = $_GET['id_trajet'];

    // Get trip information
    $trip_query = "SELECT * FROM Trajet WHERE ID_Trajet = $1 AND ID_Utilisateur = $2";
    $trip_result = pg_query_params($dbconn, $trip_query, array($id_trajet, $id_utilisateur));
    $trip = pg_fetch_assoc($trip_result);

    if ($trip) {
        // Get all stops
        $stops_query = "SELECT ar.adresse_arret, ar.CP_ville, ar.Details, ar.num_Arret 
                        FROM Comprend co 
                        JOIN Arret ar ON co.adresse_arret = ar.adresse_arret 
                        WHERE co.ID_Trajet = $1 ORDER BY ar.num_Arret ASC";
        $stops_result = pg_query_params($dbconn, $stops_query, array($id_trajet));
        $stops = pg_fetch_all($stops_result);

        if (!$stops) {
            echo "<script>alert('Erreur: impossible de récupérer les arrêts.'); window.history.back();</script>";
            exit();
        }
    } else {
        echo "<script>alert('Erreur: Trajet non trouvé ou vous n\'êtes pas autorisé à le modifier.'); window.history.back();</script>";
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_trajet'])) {
    $id_trajet = $_POST['id_trajet'];
    $new_stops = $_POST['stops'] ?? [];
    $new_stop_ids = [];

    // Begin transaction
    pg_query($dbconn, "BEGIN");

    // Delete all current stops
    $delete_comprend_query = "DELETE FROM Comprend WHERE ID_Trajet = $1";
    $delete_comprend_result = pg_query_params($dbconn, $delete_comprend_query, array($id_trajet));

    if ($delete_comprend_result) {
        // Insert new stops
        foreach ($new_stops as $index => $stop) {
            // Ensure that all required fields are set
            $adresse_arret = isset($stop['adresse_arret']) ? pg_escape_string($dbconn, $stop['adresse_arret']) : null;
            $cp_ville = isset($stop['CP_ville']) && is_numeric($stop['CP_ville']) ? intval($stop['CP_ville']) : null;
            $details = isset($stop['Details']) ? pg_escape_string($dbconn, $stop['Details']) : null;
            $num_arret = $index + 1;

            if ($adresse_arret && $cp_ville && $details) {
                $stop_query = "INSERT INTO Arret (adresse_arret, CP_ville, Details, num_Arret) VALUES ($1, $2, $3, $4) 
                               ON CONFLICT (adresse_arret) DO UPDATE SET CP_ville = $2, Details = $3, num_Arret = $4 RETURNING adresse_arret";
                $stop_result = pg_query_params($dbconn, $stop_query, array($adresse_arret, $cp_ville, $details, $num_arret));

                if ($stop_result) {
                    $stop_row = pg_fetch_assoc($stop_result);
                    $adresse_arret = $stop_row['adresse_arret'];
                    $new_stop_ids[] = $adresse_arret;

                    $comprend_query = "INSERT INTO Comprend (ID_Trajet, adresse_arret) VALUES ($1, $2)";
                    $comprend_result = pg_query_params($dbconn, $comprend_query, array($id_trajet, $adresse_arret));

                    if (!$comprend_result) {
                        pg_query($dbconn, "ROLLBACK");
                        echo "<script>alert('Erreur lors de l\'insertion des arrêts : " . pg_last_error($dbconn) . "');</script>";
                        exit();
                    }
                } else {
                    pg_query($dbconn, "ROLLBACK");
                    echo "<script>alert('Erreur lors de l\'insertion des arrêts : " . pg_last_error($dbconn) . "');</script>";
                    exit();
                }
            } else {
                pg_query($dbconn, "ROLLBACK");
                echo "<script>alert('Erreur: Tous les champs des arrêts doivent être renseignés.');</script>";
                exit();
            }
        }

        // Notify passengers
        $passengers_query = "SELECT ID_Utilisateur FROM Reserve WHERE ID_Trajet = $1";
        $passengers_result = pg_query_params($dbconn, $passengers_query, array($id_trajet));
        $passengers = pg_fetch_all($passengers_result) ?: [];

        $trip_info = "Trajet de " . htmlspecialchars($trip['ville_depart']) . " à " . htmlspecialchars($trip['ville_destination']) . " le " . htmlspecialchars($trip['date_trajet']) . " à " . htmlspecialchars($trip['heure_depart']);

        foreach ($passengers as $passenger) {
            $message_content = "Le trajet que vous avez réservé a été modifié. Nouveaux arrêts: " . implode(", ", array_column($new_stops, 'adresse_arret')) . ". Détails du trajet: $trip_info.";
            $message_query = "INSERT INTO Message (Contenu_message, Date_d_envoie, ID_Utilisateur, ID_Utilisateur_1) VALUES ($1, CURRENT_TIMESTAMP, $2, $3)";
            $message_result = pg_query_params($dbconn, $message_query, array($message_content, $id_utilisateur, $passenger['id_utilisateur']));

            if (!$message_result) {
                pg_query($dbconn, "ROLLBACK");
                echo "<script>alert('Erreur lors de l\'envoi du message: " . pg_last_error($dbconn) . "');</script>";
                exit();
            }
        }

        pg_query($dbconn, "COMMIT");
        echo "<script>alert('Arrêts mis à jour et passagers notifiés.'); window.location.href='trajets.php';</script>";
    } else {
        pg_query($dbconn, "ROLLBACK");
        echo "<script>alert('Erreur lors de la suppression des arrêts actuels : " . pg_last_error($dbconn) . "');</script>";
    }
}

pg_close($dbconn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modifier les Arrêts</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
    <script>
        function addStop() {
            const stopsContainer = document.getElementById('stops-container');
            const stopTemplate = document.getElementById('stop-template').content.cloneNode(true);
            stopsContainer.appendChild(stopTemplate);
        }

        function removeStop(event) {
            const stop = event.target.closest('.stop');
            stop.remove();
        }
    </script>
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function() {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>
    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Modifier les Arrêts</h2>
            </header>
            <?php if (!empty($trip) && !empty($stops)): ?>
            <form action="modify_stops.php" method="POST" class="field-set">
                <input type="hidden" name="id_trajet" value="<?= htmlspecialchars($trip['id_trajet']) ?>">
                <div id="stops-container">
                    <?php foreach ($stops as $stop): ?>
                    <div class="stop">
                        <span class="input-item">
                            <i class="fa fa-address-card"></i>
                        </span>
                        <input class="form-input" type="text" name="stops[<?= htmlspecialchars($stop['adresse_arret']) ?>][adresse_arret]" value="<?= htmlspecialchars($stop['adresse_arret']) ?>" placeholder="Adresse de l'Arrêt" required><br>

                        <span class="input-item">
                            <i class="fa fa-map-marker"></i>
                        </span>
                        <input class="form-input" type="number" name="stops[<?= htmlspecialchars($stop['adresse_arret']) ?>][CP_ville]" value="<?= htmlspecialchars($stop['cp_ville']) ?>" placeholder="Code Postal / Ville" required><br>

                        <span class="input-item">
                            <i class="fa fa-info-circle"></i>
                        </span>
                        <textarea class="form-input" name="stops[<?= htmlspecialchars($stop['adresse_arret']) ?>][Details]" placeholder="Détails" required><?= htmlspecialchars($stop['details']) ?></textarea><br>

                        <button class="submit-button" type="button" onclick="removeStop(event)">Supprimer cet arrêt</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button class="submit-button" type="button" onclick="addStop()">Ajouter un arrêt</button><br>
                <button class="submit-button" type="submit">Enregistrer les modifications</button>
            </form>
            <?php else: ?>
                <p>Erreur: Trajet ou arrêts non trouvés.</p>
            <?php endif; ?>
        </div>
    </div>
    <template id="stop-template">
        <div class="stop">
            <span class="input-item">
                <i class="fa fa-address-card"></i>
            </span>
            <input class="form-input" type="text" name="stops[][adresse_arret]" placeholder="Adresse de l'Arrêt" required><br>

            <span class="input-item">
                <i class="fa fa-map-marker"></i>
            </span>
            <input class="form-input" type="number" name="stops[][CP_ville]" placeholder="Code Postal / Ville" required><br>

            <span class="input-item">
                <i class="fa fa-info-circle"></i>
            </span>
            <textarea class="form-input" name="stops[][Details]" placeholder="Détails" required></textarea><br>

            <button class="submit-button" type="button" onclick="removeStop(event)">Supprimer cet arrêt</button>
        </div>
    </template>
</body>
</html>
