<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['id_utilisateur'];

// Get added trips
$added_trips_query = "SELECT * FROM Trajet WHERE ID_Utilisateur = $1";
$added_trips_result = pg_query_params($dbconn, $added_trips_query, array($user_id));
$added_trips = pg_fetch_all($added_trips_result);

// Get reserved trips
$reserved_trips_query = "SELECT t.*, u.Prenom_Utilisateur, u.Adresse_EMail, u.ID_Utilisateur AS DriverID FROM Reserve r JOIN Trajet t ON r.ID_Trajet = t.ID_Trajet JOIN Utilisateur u ON t.ID_Utilisateur = u.ID_Utilisateur WHERE r.ID_Utilisateur = $1";
$reserved_trips_result = pg_query_params($dbconn, $reserved_trips_query, array($user_id));
$reserved_trips = pg_fetch_all($reserved_trips_result);

pg_close($dbconn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vos Trajets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">    
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function() {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>
    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Vos Trajets</h2>
            </header>
            <div class="tabs">
                <button class="tab active" onclick="openTab(event, 'added-trips')">Trajets Ajoutés</button>
                <button class="tab" onclick="openTab(event, 'reserved-trips')">Trajets Réservés</button>
            </div>
            <div id="added-trips" class="tab-content active">
                <?php if (!empty($added_trips)) : ?>
                    <ul>
                        <?php foreach ($added_trips as $trip) : ?>
                            <li class="aff">
                                <p>Départ: <?= htmlspecialchars($trip['ville_depart']) ?></p>
                                <p>Destination: <?= htmlspecialchars($trip['ville_destination']) ?></p>
                                <p>Date: <?= htmlspecialchars($trip['date_trajet']) ?></p>
                                <form action="edit_trip.php" method="GET" style="display: inline;">
                                    <input type="hidden" name="id_trajet" value="<?= $trip['id_trajet'] ?>">
                                    <button class="submit-button" type="submit">Modifier</button>
                                </form>
                                <form action="delete_trip.php" method="POST" style="display: inline;">
                                    <input type="hidden" name="id_trajet" value="<?= $trip['id_trajet'] ?>">
                                    <button class="submit-button" type="submit" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce trajet?');">Supprimer</button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else : ?>
                    <p>Vous n'avez ajouté aucun trajet.</p>
                <?php endif; ?>
            </div>
            <div id="reserved-trips" class="tab-content">
                <?php if (!empty($reserved_trips)) : ?>
                    <ul>
                        <?php foreach ($reserved_trips as $trip) : ?>
                            <li class="aff">
                                <p>Départ: <?= htmlspecialchars($trip['ville_depart']) ?></p>
                                <p>Destination: <?= htmlspecialchars($trip['ville_destination']) ?></p>
                                <p>Date: <?= htmlspecialchars($trip['date_trajet']) ?></p>
                                <form action="laisser_avis.php" method="POST" style="display: inline;">
                                    <input type="hidden" name="id_trajet" value="<?= $trip['id_trajet'] ?>">
                                    <button class="submit-button" type="submit">Laisser un avis</button>
                                </form>
                                <form action="cancel_reservation.php" method="POST" style="display: inline;">
                                    <input type="hidden" name="id_trajet" value="<?= $trip['id_trajet'] ?>">
                                    <input type="hidden" name="driver_id" value="<?= $trip['driverid'] ?>">
                                    <button class="submit-button" type="submit" onclick="return confirm('Êtes-vous sûr de vouloir annuler cette réservation?');">Annuler</button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else : ?>
                    <p>Vous n'avez réservé aucun trajet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function openTab(evt, tabId) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            tablinks = document.getElementsByClassName("tab");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            document.getElementById(tabId).classList.add("active");
            evt.currentTarget.classList.add("active");
        }
    </script>
</body>
</html>
