<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_trajet = $_POST['id_trajet'];
    $user_id = $_SESSION['id_utilisateur'];

    // Begin transaction
    pg_query($dbconn, "BEGIN");

    // Get the IDs of the stops to delete from the Arret table
    $get_arrets_query = "SELECT ID_arret FROM Comprend WHERE ID_Trajet = $1";
    $get_arrets_result = pg_query_params($dbconn, $get_arrets_query, array($id_trajet));
    $arrets = pg_fetch_all($get_arrets_result);

    if ($arrets) {
        // Delete associated records from Comprend table
        $delete_comprend_query = "DELETE FROM Comprend WHERE ID_Trajet = $1";
        $delete_comprend_result = pg_query_params($dbconn, $delete_comprend_query, array($id_trajet));

        if ($delete_comprend_result) {
            // Delete the trip from Trajet table
            $delete_trip_query = "DELETE FROM Trajet WHERE ID_Trajet = $1 AND ID_Utilisateur = $2";
            $delete_trip_result = pg_query_params($dbconn, $delete_trip_query, array($id_trajet, $user_id));

            if ($delete_trip_result) {
                // Delete stops from Arret table
                foreach ($arrets as $arret) {
                    $delete_arret_query = "DELETE FROM Arret WHERE ID_arret = $1";
                    $delete_arret_result = pg_query_params($dbconn, $delete_arret_query, array($arret['id_arret']));

                    if (!$delete_arret_result) {
                        // Rollback transaction
                        pg_query($dbconn, "ROLLBACK");
                        echo "<script>alert('Erreur lors de la suppression des arrêts : " . pg_last_error($dbconn) . "'); window.location.href='trajets.php';</script>";
                        exit();
                    }
                }

                // Commit transaction
                pg_query($dbconn, "COMMIT");
                echo "<script>alert('Trajet supprimé avec succès.'); window.location.href='trajets.php';</script>";
            } else {
                // Rollback transaction
                pg_query($dbconn, "ROLLBACK");
                echo "<script>alert('Erreur lors de la suppression du trajet : " . pg_last_error($dbconn) . "'); window.location.href='trajets.php';</script>";
            }
        } else {
            // Rollback transaction
            pg_query($dbconn, "ROLLBACK");
            echo "<script>alert('Erreur lors de la suppression des arrêts associés : " . pg_last_error($dbconn) . "'); window.location.href='trajets.php';</script>";
        }
    } else {
        // Rollback transaction
        pg_query($dbconn, "ROLLBACK");
        echo "<script>alert('Erreur lors de la récupération des arrêts associés : " . pg_last_error($dbconn) . "'); window.location.href='trajets.php';</script>";
    }

    pg_close($dbconn);
}
?>
