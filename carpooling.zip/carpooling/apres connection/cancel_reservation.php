<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_trajet']) && isset($_POST['driver_id'])) {
    $trip_id = $_POST['id_trajet'];
    $passenger_id = $_SESSION['id_utilisateur'];
    $driver_id = $_POST['driver_id'];

    // Retrieve trip details
    $trip_query = "SELECT * FROM Trajet WHERE ID_Trajet = $1";
    $trip_result = pg_query_params($dbconn, $trip_query, array($trip_id));
    $trip_details = pg_fetch_assoc($trip_result);

    if (!$trip_details) {
        echo "<script>alert('Erreur: Trajet non trouvé.'); window.location.href='trajets.php';</script>";
        exit();
    }

    $trip_info = "Trajet de " . htmlspecialchars($trip_details['ville_depart']) . " à " . htmlspecialchars($trip_details['ville_destination']) . " le " . htmlspecialchars($trip_details['date_trajet']) . " à " . htmlspecialchars($trip_details['heure_depart']);

    // Begin transaction
    pg_query($dbconn, "BEGIN");

    // Delete reservation
    $delete_reservation_query = "DELETE FROM Reserve WHERE ID_Utilisateur = $1 AND ID_Trajet = $2";
    $delete_reservation_result = pg_query_params($dbconn, $delete_reservation_query, array($passenger_id, $trip_id));

    if ($delete_reservation_result) {
        // Send cancellation message to driver
        $message_content = "Le passager a annulé la réservation pour le $trip_info.";
        $message_query = "INSERT INTO Message (Contenu_message, Date_d_envoie, ID_Utilisateur, ID_Utilisateur_1) VALUES ($1, CURRENT_TIMESTAMP, $2, $3)";
        $message_result = pg_query_params($dbconn, $message_query, array($message_content, $passenger_id, $driver_id));

        if ($message_result) {
            // Commit transaction
            pg_query($dbconn, "COMMIT");
            echo "<script>alert('Réservation annulée avec succès et le conducteur a été notifié.'); window.location.href='trajets.php';</script>";
        } else {
            // Rollback transaction
            pg_query($dbconn, "ROLLBACK");
            echo "<script>alert('Erreur lors de l\'envoi du message: " . pg_last_error($dbconn) . "'); window.location.href='trajets.php';</script>";
        }
    } else {
        // Rollback transaction
        pg_query($dbconn, "ROLLBACK");
        echo "<script>alert('Erreur lors de l\'annulation de la réservation: " . pg_last_error($dbconn) . "'); window.location.href='trajets.php';</script>";
    }

    pg_close($dbconn);
}
?>
