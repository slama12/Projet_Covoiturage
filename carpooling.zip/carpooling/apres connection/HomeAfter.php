<?php
session_start();

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

$prenom = $_SESSION['prenom'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accueil - Covoiturage</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/Home_style.css">
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                    document.getElementById('profile-name').innerText = "<?php echo htmlspecialchars($prenom); ?>";
                    document.getElementById('profile-name-mobile').textContent = "<?php echo $prenom; ?>";
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="hero">
        <div class="hero-content">
            <h1>Bienvenue, <?php echo htmlspecialchars($prenom); ?> !</h1>
            <p>Nous sommes ravis de vous revoir.</p>
            <a href='publier_trajet.html' class="btn">Publier un trajet</a>
            <a href='rechercher.html' class="btn">Rechercher un trajet</a>
        </div>
    </div>

    <section class="features">
        <div class="feature">
            <i class="fas fa-car"></i>
            <h2>Voyagez Economiquement</h2>
            <p>Partagez des trajets pour économiser sur les frais de déplacement.</p>
        </div>
        <div class="feature">
            <i class="fas fa-users"></i>
            <h2>Rencontrez de Nouvelles Personnes</h2>
            <p>Faites des rencontres et voyagez en bonne compagnie.</p>
        </div>
        <div class="feature">
            <i class="fas fa-globe"></i>
            <h2>Réduisez votre Emprunte Carbone</h2>
            <p>Contribuez à la protection de l'environnement en partageant vos trajets.</p>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 Covoiturage. Tous droits réservés.</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>
