<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['id_utilisateur'];

// Get reviews left by the user
$left_reviews_query = "SELECT a.*, t.Ville_depart, t.Ville_destination, u.Prenom_Utilisateur AS Conducteur
                      FROM Avis a
                      JOIN Trajet t ON a.ID_Trajet = t.ID_Trajet
                      JOIN Utilisateur u ON t.ID_Utilisateur = u.ID_Utilisateur
                      WHERE a.ID_Utilisateur_CIR = $1";
$left_reviews_result = pg_query_params($dbconn, $left_reviews_query, array($user_id));
$left_reviews = pg_fetch_all($left_reviews_result);

// Get reviews received by the user as a driver
$received_reviews_query = "SELECT a.*, t.Ville_depart, t.Ville_destination, u.Prenom_Utilisateur AS Passager
                          FROM Avis a
                          JOIN Trajet t ON a.ID_Trajet = t.ID_Trajet
                          JOIN Utilisateur u ON a.ID_Utilisateur_CIR = u.ID_Utilisateur
                          WHERE t.ID_Utilisateur = $1";
$received_reviews_result = pg_query_params($dbconn, $received_reviews_query, array($user_id));
$received_reviews = pg_fetch_all($received_reviews_result);

pg_close($dbconn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vos Avis</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">    
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>
    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Vos Avis</h2>
            </header>
            <div class="tabs">
                <button class="tab active" onclick="openTab(event, 'left-reviews')">Avis Laissés</button>
                <button class="tab" onclick="openTab(event, 'received-reviews')">Avis Reçus</button>
            </div>
            <div id="left-reviews" class="tab-content active">
                <?php if (!empty($left_reviews)) : ?>
                    <ul>
                        <?php foreach ($left_reviews as $review) : ?>
                            <li class="aff">
                                <p>Départ: <?= htmlspecialchars($review['ville_depart']) ?></p>
                                <p>Destination: <?= htmlspecialchars($review['ville_destination']) ?></p>
                                <p>Au Conducteur: <?= htmlspecialchars($review['conducteur']) ?></p>
                                <p>Note: <?= htmlspecialchars($review['note']) ?></p>
                                <p>Commentaire: <?= htmlspecialchars($review['commentaire']) ?></p>
                                <p>Date: <?= htmlspecialchars($review['date_avis']) ?></p>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else : ?>
                    <p>Vous n'avez laissé aucun avis.</p>
                <?php endif; ?>
            </div>
            <div id="received-reviews" class="tab-content">
                <?php if (!empty($received_reviews)) : ?>
                    <ul>
                        <?php foreach ($received_reviews as $review) : ?>
                            <li class="aff">
                                <p>Départ: <?= htmlspecialchars($review['ville_depart']) ?></p>
                                <p>Destination: <?= htmlspecialchars($review['ville_destination']) ?></p>
                                <p>Du Passager: <?= htmlspecialchars($review['passager']) ?></p>
                                <p>Note: <?= htmlspecialchars($review['note']) ?></p>
                                <p>Commentaire: <?= htmlspecialchars($review['commentaire']) ?></p>
                                <p>Date: <?= htmlspecialchars($review['date_avis']) ?></p>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else : ?>
                    <p>Vous n'avez reçu aucun avis.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function openTab(evt, tabId) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            tablinks = document.getElementsByClassName("tab");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            document.getElementById(tabId).classList.add("active");
            evt.currentTarget.classList.add("active");
        }
    </script>
</body>
</html>
