<?php
session_start();
include '../db/db_connect.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html");
    exit();
}

$trajets = [];
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ville_depart = $_POST['ville_depart'];
    $ville_destination = $_POST['ville_destination'];
    $date = $_POST['date'];
    $passagers = (int)$_POST['passagers'];

    // Requête pour trouver les trajets correspondant
    $query = "SELECT * FROM Trajet WHERE Ville_depart = $1 AND Ville_destination = $2 AND Date_trajet = $3 AND Places_disponibles >= $4";
    $result = pg_query_params($dbconn, $query, array($ville_depart, $ville_destination, $date, $passagers));

    if ($result) {
        $trajets = pg_fetch_all($result);
    } else {
        $error_message = "Erreur lors de la recherche de trajets: " . pg_last_error($dbconn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Résultats de la Recherche</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #fff;
            margin: 0;
            padding: 0;
            padding-top: 70px;
        }

        .container {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            max-width: 800px;
            width: 100%;
            margin: 20px auto; /* Center the container */
            /* box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); */
        }

        .container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #20c997; /* Teal */
            font-size: 24px;
        }

        .container ul {
            list-style-type: none;
            padding: 0;
        }

        .container ul li {
            background-color: #f1f1f1;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .container ul li p {
            margin: 5px 0;
        }

        .container ul li form {
            margin: 0;
        }

        .container ul li button {
            background: #20c997;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }

        .container ul li button:hover {
            background: #17a2b8;
        }

        .no-results {
            text-align: center;
            font-size: 18px;
            color: #666;
        }
    </style>
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="container">
        <h2>Résultats de la Recherche</h2>
        <?php if ($error_message): ?>
            <p class="no-results"><?= htmlspecialchars($error_message) ?></p>
        <?php elseif (!empty($trajets)): ?>
            <ul>
                <?php foreach ($trajets as $trajet): ?>
                    <?php
                    // Check if the user has already reserved this trip
                    $check_reservation_query = "SELECT * FROM Reserve WHERE ID_Utilisateur = $1 AND ID_Trajet = $2";
                    $check_reservation_result = pg_query_params($dbconn, $check_reservation_query, array($_SESSION['id_utilisateur'], $trajet['id_trajet']));
                    $already_reserved = pg_num_rows($check_reservation_result) > 0;
                    ?>
                    <li>
                        <div>
                            <p>Départ: <?= htmlspecialchars($trajet['ville_depart']) ?></p>
                            <p>Destination: <?= htmlspecialchars($trajet['ville_destination']) ?></p>
                            <p>Date: <?= htmlspecialchars($trajet['date_trajet']) ?></p>
                        </div>
                        <form action="reserver_trajet.php" method="POST">
                            <input type="hidden" name="id_trajet" value="<?= $trajet['id_trajet'] ?>">
                            <button type="submit" <?= $already_reserved ? 'disabled' : '' ?>><?= $already_reserved ? 'Déjà réservé' : 'Réserver' ?></button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="no-results">Aucun trajet trouvé.</p>
        <?php endif; ?>
    </div>
</body>
</html>
