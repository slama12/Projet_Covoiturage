<?php
session_start();

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirmation de Réservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #fff;
            margin: 0;
            padding: 0;
            padding-top: 70px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            max-width: 800px;
            width: 100%;
            margin: 20px auto;
            /* box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); */
            text-align: center;
        }

        .container h2 {
            color: #20c997; /* Teal */
            font-size: 24px;
            margin-bottom: 20px;
        }

        .container p {
            font-size: 18px;
            color: #666;
            margin-bottom: 20px;
        }

        .container a {
            color: #20c997; /* Teal */
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s;
        }

        .container a:hover {
            color: #17a2b8; /* Darker shade of teal */
        }
    </style>
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="container">
        <h2>Réservation Confirmée</h2>
        <p>Votre réservation a été confirmée avec succès et un message de confirmation a été envoyé par le conducteur.</p>
        <a href="../apres connection/HomeAfter.php">Retour à l'accueil</a>
    </div>
</body>
</html>
