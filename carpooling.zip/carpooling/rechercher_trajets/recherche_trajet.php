<?php
session_start();
include '../db/db_connect.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Recherche de Trajet</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
</head>

<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function() {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="overlay">
        <form action="resultats_recherche.php" method="POST">
        <div class="con">
                <header class="head-form">
                    <h2>Rechercher un Trajet</h2>
                </header>
                <div class="field-set">
                    <span class="input-item">
                        <i class="fas fa-map-marker-alt"></i>
                    </span>
                    <input class="form-input" type="text" id="ville_depart" name="ville_depart" placeholder="Ville de départ" required>
                </div>
                <div class="field-set">
                    <span class="input-item">
                        <i class="fas fa-map-marker-alt"></i>
                    </span>
                    <input class="form-input" type="text" id="ville_destination" name="ville_destination" placeholder="Ville de destination" required>
                </div>
                <div class="field-set">
                    <span class="input-item">
                        <i class="fas fa-calendar-alt"></i>
                    </span>
                    <input class="form-input" type="date" id="date" name="date" required>
                </div>
                <div class="field-set">
                    <span class="input-item">
                        <i class="fas fa-user"></i>
                    </span>
                    <input class="form-input" type="number" id="passagers" name="passagers" min="1" max="4" value="1" placeholder="Nombre de passagers" required>
                </div>
                <button class="submit-button" type="submit"><i class="fas fa-search"></i> Rechercher</button>
            </div>
        </form>
    </div>

    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script>
        // Set the default value of the date input to today's date
        document.getElementById('date').valueAsDate = new Date();
    </script>
</body>
</html>