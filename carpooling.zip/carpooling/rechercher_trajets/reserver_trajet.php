<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_trajet'])) {
    $trip_id = $_POST['id_trajet'];
    $passenger_id = $_SESSION['id_utilisateur'];

    // Check if the user has already reserved the trip
    $check_reservation_query = "SELECT * FROM Reserve WHERE ID_Utilisateur = $1 AND ID_Trajet = $2";
    $check_reservation_result = pg_query_params($dbconn, $check_reservation_query, array($passenger_id, $trip_id));
    
    if (pg_num_rows($check_reservation_result) > 0) {
        echo "<script>alert('Vous avez déjà réservé ce trajet.'); window.location.href='../rechercher_trajets/trajets.php';</script>";
        exit();
    }

    // Get trip details and driver information
    $trip_query = "SELECT t.*, u.Adresse_EMail, u.ID_Utilisateur AS DriverID, u.Prenom_Utilisateur
                   FROM Trajet t
                   JOIN Utilisateur u ON t.ID_Utilisateur = u.ID_Utilisateur
                   WHERE t.ID_Trajet = $1";
    $trip_result = pg_query_params($dbconn, $trip_query, array($trip_id));
    if ($trip_row = pg_fetch_assoc($trip_result)) {
        $driver_id = $trip_row['driverid'];
        $driver_name = $trip_row['prenom_utilisateur'];
        $trip_details = "Trip from " . $trip_row['ville_depart'] . " to " . $trip_row['ville_destination'] . " on " . $trip_row['date_trajet'] . " at " . $trip_row['heure_depart'];

        // Insert reservation
        $reservation_query = "INSERT INTO Reserve (ID_Utilisateur, ID_Trajet, Statut_reservation, Date_Reservation) VALUES ($1, $2, 'confirmée', CURRENT_DATE)";
        $reservation_result = pg_query_params($dbconn, $reservation_query, array($passenger_id, $trip_id));

        if ($reservation_result) {
            // Send initial message from driver to passenger
            $message_content = "Hello, you have booked a trip with $driver_name. Here are the details: " . $trip_details;
            $message_query = "INSERT INTO Message (Contenu_message, Date_d_envoie, ID_Utilisateur, ID_Utilisateur_1) VALUES ($1, CURRENT_TIMESTAMP, $2, $3)";
            $message_result = pg_query_params($dbconn, $message_query, array($message_content, $driver_id, $passenger_id));

            if ($message_result) {
                echo "Booking successful and message sent!";
                header("Location: confirmation.php");
                exit();
            } else {
                echo "Error sending message: " . pg_last_error($dbconn);
            }
        } else {
            echo "Error booking trip: " . pg_last_error($dbconn);
        }
    } else {
        echo "Trip not found.";
    }

    pg_free_result($trip_result);
    pg_close($dbconn);
}
?>
