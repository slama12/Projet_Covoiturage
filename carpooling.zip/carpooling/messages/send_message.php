<?php
session_start();
include '../db/db_connect.php';

// Fetch trips for which the current user is either a driver or a passenger
$user_id = $_SESSION['id_utilisateur'];
$query = "SELECT t.ID_Trajet, t.lieu_de_rendez_vous, t.Date_trajet 
          FROM Trajet t 
          LEFT JOIN Reserve r ON t.ID_Trajet = r.ID_Trajet
          WHERE t.ID_Utilisateur = $1 OR r.ID_Utilisateur = $1";
$result = pg_query_params($dbconn, $query, array($user_id));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Message</title>
    <link rel="stylesheet" href="../template/message_style.css"> <!-- Optional: Add CSS file for styling -->
</head>
<body>
    <h2>Send a Message</h2>
    <form action="process_message.php" method="POST">
        <label for="trip">Trip:</label>
        <select id="trip" name="trip" required>
            <?php while ($row = pg_fetch_assoc($result)) { ?>
                <option value="<?php echo $row['id_trajet']; ?>">
                    <?php echo htmlspecialchars($row['lieu_de_rendez_vous']) . " on " . htmlspecialchars($row['date_trajet']); ?>
                </option>
            <?php } ?>
        </select><br><br>

        <label for="recipient">Recipient Email:</label>
        <input type="email" id="recipient" name="recipient" required><br><br>

        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="5" cols="50" required></textarea><br><br>

        <button type="submit">Send Message</button>
    </form>
</body>
</html>
<?php pg_free_result($result); pg_close($dbconn); ?>
