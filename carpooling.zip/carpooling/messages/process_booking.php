<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $trip_id = $_POST['trip_id'];
    $passenger_id = $_SESSION['id_utilisateur'];

    // Get trip details and driver information
    $trip_query = "SELECT t.*, u.Adresse_EMail, u.ID_Utilisateur AS DriverID
                   FROM Trajet t
                   JOIN Utilisateur u ON t.ID_Utilisateur = u.ID_Utilisateur
                   WHERE t.ID_Trajet = $1";
    $trip_result = pg_query_params($dbconn, $trip_query, array($trip_id));
    if ($trip_row = pg_fetch_assoc($trip_result)) {
        $driver_id = $trip_row['DriverID'];
        $trip_details = "Trip from " . $trip_row['lieu_de_rendez_vous'] . " on " . $trip_row['Date_trajet'] . " at " . $trip_row['heure_depart'];

        // Insert reservation
        $reservation_query = "INSERT INTO Reserve (ID_Utilisateur, ID_Trajet, Statut_reservation, Date_Reservation) VALUES ($1, $2, 'Booked', CURRENT_DATE)";
        $reservation_result = pg_query_params($dbconn, $reservation_query, array($passenger_id, $trip_id));

        if ($reservation_result) {
            // Send initial message from driver to passenger
            $message_content = "Hello, you have booked a trip. Here are the details: " . $trip_details;
            $message_query = "INSERT INTO Message (Contenu_message, Date_d_envoie, ID_Utilisateur, ID_Utilisateur_1) VALUES ($1, CURRENT_TIMESTAMP, $2, $3)";
            $message_result = pg_query_params($dbconn, $message_query, array($message_content, $driver_id, $passenger_id));

            if ($message_result) {
                echo "Booking successful and message sent!";
                header("Location: messages.php");
                exit();
            } else {
                echo "Error sending message: " . pg_last_error($dbconn);
            }
        } else {
            echo "Error booking trip: " . pg_last_error($dbconn);
        }
    } else {
        echo "Trip not found.";
    }

    pg_free_result($trip_result);
    pg_close($dbconn);
}
?>
