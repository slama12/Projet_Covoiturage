<?php
session_start();

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

include '../db/db_connect.php'; // Adjust the path as needed

$user_id = $_SESSION['id_utilisateur'];
$prenom = $_SESSION['prenom'];

// Retrieve received messages
$received_messages_query = "SELECT m.Contenu_message, m.Date_d_envoie, u.Nom_Utilisateur, u.Prenom_Utilisateur
                            FROM Message m
                            JOIN Utilisateur u ON m.ID_Utilisateur = u.ID_Utilisateur
                            WHERE m.ID_Utilisateur_1 = $1
                            ORDER BY m.Date_d_envoie DESC";
$received_messages_result = pg_query_params($dbconn, $received_messages_query, array($user_id));

// Retrieve sent messages
$sent_messages_query = "SELECT m.Contenu_message, m.Date_d_envoie, u.Nom_Utilisateur, u.Prenom_Utilisateur
                        FROM Message m
                        JOIN Utilisateur u ON m.ID_Utilisateur_1 = u.ID_Utilisateur
                        WHERE m.ID_Utilisateur = $1
                        ORDER BY m.Date_d_envoie DESC";
$sent_messages_result = pg_query_params($dbconn, $sent_messages_query, array($user_id));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Messages - Covoiturage</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/message_style.css"> <!-- Create a separate CSS file for messages styling -->
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                    document.getElementById('profile-name').innerText = "<?php echo htmlspecialchars($prenom); ?>";
                    document.getElementById('profile-name-mobile').textContent = "<?php echo htmlspecialchars($prenom); ?>";
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="container">
        <h2>Messages</h2>
        <form action="process_message.php" method="POST">
            <label for="recipient">Recipient Email:</label>
            <input type="email" id="recipient" name="recipient" required><br>

            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="5" cols="50" required></textarea><br>

            <button type="submit">Send Message</button>
        </form>

        <h3>Received Messages</h3>
        <div id="received-messages" class="message-container">
            <?php
            if (pg_num_rows($received_messages_result) > 0) {
                while ($row = pg_fetch_assoc($received_messages_result)) {
                    echo "<div class='message'>";
                    echo "<p><strong>From:</strong> " . htmlspecialchars($row['prenom_utilisateur']) . " " . htmlspecialchars($row['nom_utilisateur']) . "</p>";
                    echo "<p><strong>Sent:</strong> " . htmlspecialchars($row['date_d_envoie']) . "</p>";
                    echo "<p>" . nl2br(htmlspecialchars($row['contenu_message'])) . "</p>";
                    echo "</div><hr>";
                }
            } else {
                echo "<p>No messages found.</p>";
            }
            ?>
        </div>

        <h3>Sent Messages</h3>
        <div id="sent-messages" class="message-container">
            <?php
            if (pg_num_rows($sent_messages_result) > 0) {
                while ($row = pg_fetch_assoc($sent_messages_result)) {
                    echo "<div class='message'>";
                    echo "<p><strong>To:</strong> " . htmlspecialchars($row['prenom_utilisateur']) . " " . htmlspecialchars($row['nom_utilisateur']) . "</p>";
                    echo "<p><strong>Sent:</strong> " . htmlspecialchars($row['date_d_envoie']) . "</p>";
                    echo "<p>" . nl2br(htmlspecialchars($row['contenu_message'])) . "</p>";
                    echo "</div><hr>";
                }
            } else {
                echo "<p>No messages found.</p>";
            }
            ?>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
<?php
pg_free_result($received_messages_result);
pg_free_result($sent_messages_result);
pg_close($dbconn);
?>
