<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sender_id = $_SESSION['id_utilisateur'];
    $recipient_email = pg_escape_string($dbconn, $_POST['recipient']);
    $message_content = pg_escape_string($dbconn, $_POST['message']);
    $date_envoie = date('Y-m-d H:i:s');

    // Retrieve recipient's user ID using their email
    $query = "SELECT ID_Utilisateur FROM Utilisateur WHERE Adresse_EMail = $1";
    $result = pg_query_params($dbconn, $query, array($recipient_email));

    if ($row = pg_fetch_assoc($result)) {
        $recipient_id = $row['id_utilisateur'];

        // Insert the message into the database
        $insert_query = "INSERT INTO Message (Contenu_message, Date_d_envoie, ID_Utilisateur, ID_Utilisateur_1)
                         VALUES ($1, $2, $3, $4)";
        $insert_result = pg_query_params($dbconn, $insert_query, array($message_content, $date_envoie, $sender_id, $recipient_id));

        if ($insert_result) {
            echo "Message sent successfully!";
            header("Location: messages.php"); // Redirect to messages page
            exit();
        } else {
            echo "Error sending message: " . pg_last_error($dbconn);
        }
    } else {
        echo "Recipient not found.";
    }

    pg_free_result($result);
    pg_close($dbconn);
} else {
    echo "Invalid request.";
}
?>
