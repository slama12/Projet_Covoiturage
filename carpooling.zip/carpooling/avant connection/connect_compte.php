<?php
session_start(); // Démarrer la session
include '../db/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["verif_email"])) {
        $email = pg_escape_string($dbconn, $_POST['txt-email']);
        // Vérifier si l'email existe dans la base de données
        $query = "SELECT * FROM Utilisateur WHERE Adresse_EMail = $1";
        $result = pg_query_params($dbconn, $query, array($email));

        if (pg_num_rows($result) === 0) {
            // Rediriger vers la page de réinitialisation du mot de passe avec l'email en paramètre
            header("Location: inscription.php?email=" . urlencode($email));
            exit();
        } else {
            echo "Ce email existe deja.";
        }
        pg_free_result($result);
        pg_close($dbconn);
    } elseif (isset($_POST["signup"])) {
        // Retrieve data from form
        $username = pg_escape_string($dbconn, $_POST['nom']);
        $firstname = pg_escape_string($dbconn, $_POST['prenom']);
        $email = pg_escape_string($dbconn, $_POST['email']);
        $password = pg_escape_string($dbconn, $_POST['password']);
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $phone = pg_escape_string($dbconn, $_POST['phone']);

        // Begin transaction
        pg_query($dbconn, "BEGIN");

        $query = "INSERT INTO Utilisateur (Nom_Utilisateur, Prenom_Utilisateur, Adresse_EMail, Mot_de_Passe, Numero_Telephone) 
                  VALUES ($1, $2, $3, $4, $5) RETURNING ID_Utilisateur";
        $result = pg_query_params($dbconn, $query, array($username, $firstname, $email, $hashed_password, $phone));

        if ($result) {
            $row = pg_fetch_assoc($result);
            $user_id = $row['id_utilisateur'];

            // Assign the role 'utilisateur' to the new user
            $role_query = "INSERT INTO Affecte (ID_Utilisateur, LibelleRole) VALUES ($1, 'utilisateur')";
            $role_result = pg_query_params($dbconn, $role_query, array($user_id));

            if ($role_result) {
                // Commit transaction
                pg_query($dbconn, "COMMIT");
                echo "<script>alert('Registration successful!'); window.location='connexion.html'</script>";
            } else {
                // Rollback transaction
                pg_query($dbconn, "ROLLBACK");
                echo "Error assigning role: " . pg_last_error($dbconn);
            }
        } else {
            // Rollback transaction
            pg_query($dbconn, "ROLLBACK");
            echo "Error: " . pg_last_error($dbconn);
        }

        pg_close($dbconn);
    } elseif (isset($_POST["login"])) {
        $email = pg_escape_string($dbconn, $_POST['email']);
        $password = $_POST['password'];

        // Fetch user from the database
        $query = "SELECT * FROM Utilisateur WHERE Adresse_EMail = '$email'";
        $result = pg_query($dbconn, $query);
        $user = pg_fetch_assoc($result);

        if ($user && password_verify($password, $user['mot_de_passe'])) {
            $_SESSION['id_utilisateur'] = $user['id_utilisateur'];
            $_SESSION['nom'] = $user['nom_utilisateur'];
            $_SESSION['prenom'] = $user['prenom_utilisateur'];
            $_SESSION['email'] = $user['adresse_email'];
            $_SESSION['phone'] = $user['numero_telephone'];
            
            // Redirect to dashboard or home page
            header("Location: ../apres connection/HomeAfter.php");
            exit();
        } else {
            echo "<script>alert('Invalid username or password.'); window.location='connexion.html'</script>";
        }

        pg_close($dbconn);
    }
}
?>
