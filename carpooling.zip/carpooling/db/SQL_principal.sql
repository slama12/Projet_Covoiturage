CREATE TABLE
    Utilisateur (
        ID_Utilisateur SERIAL PRIMARY KEY,
        Nom_Utilisateur CHAR(25),
        Prenom_Utilisateur CHAR(15),
        Adresse_EMail VARCHAR(75),
        Mot_de_Passe VARCHAR(100),
        Numero_Telephone VARCHAR(20)
    );


CREATE TABLE
    Trajet (
        ID_Trajet SERIAL PRIMARY KEY,
        heure_depart TIME,
        date_ajout TIMESTAMP,
        Date_trajet DATE,
        Places_disponibles SMALLINT,
        Ville_depart VARCHAR(50),
        Ville_destination VARCHAR(50),
        ID_Utilisateur INTEGER,
        Numero_Permis VARCHAR(20),
        Date_Expiration_Permis DATE,
        FOREIGN KEY (ID_Utilisateur) REFERENCES Utilisateur (ID_Utilisateur),
    );

CREATE TABLE
    Vehicule (
        ID_Vehicule SERIAL PRIMARY KEY,
        Marque CHAR(15),
        Modele VARCHAR(50),
        Annee DATE,
        Couleur CHAR(15),
        ID_Trajet INTEGER,
        FOREIGN KEY (ID_Trajet) REFERENCES Trajet (ID_Trajet)
    );

CREATE TABLE
    Avis (
        ID_Avis SERIAL PRIMARY KEY,
        date_avis TIMESTAMP,
        Note SMALLINT,
        Commentaire TEXT,
        ID_Trajet INTEGER,
        ID_Utilisateur_CIR INTEGER,
        FOREIGN KEY (ID_Trajet) REFERENCES Trajet (ID_Trajet),
        FOREIGN KEY (ID_Utilisateur_CIR) REFERENCES Utilisateur (ID_Utilisateur)
    );

CREATE TABLE
    Message (
        ID_Message SERIAL PRIMARY KEY,
        Contenu_message TEXT,
        Date_d_envoie TIMESTAMP,
        ID_Utilisateur INTEGER,
        ID_Utilisateur_1 INTEGER,
        FOREIGN KEY (ID_Utilisateur) REFERENCES Utilisateur (ID_Utilisateur),
        FOREIGN KEY (ID_Utilisateur_1) REFERENCES Utilisateur (ID_Utilisateur)
    );

CREATE TABLE
    Arret (
        adresse_arret VARCHAR(50) PRIMARY KEY,
        num_Arret SMALLINT,
        CP_ville SMALLINT,
        Details VARCHAR(150)
    );

CREATE TABLE
    Conduit (
        ID_Utilisateur INTEGER,
        ID_Vehicule INTEGER,
        Role_Utilisateur CHAR(10) DEFAULT 'conducteur',
        PRIMARY KEY (ID_Utilisateur, ID_Vehicule),
        FOREIGN KEY (ID_Utilisateur) REFERENCES Utilisateur (ID_Utilisateur),
        FOREIGN KEY (ID_Vehicule) REFERENCES Vehicule (ID_Vehicule)
    );

CREATE TABLE Affecte (
    ID_Utilisateur INTEGER,
    LibelleRole CHAR(15),
    PRIMARY KEY (ID_Utilisateur, LibelleRole),
    FOREIGN KEY (ID_Utilisateur) REFERENCES Utilisateur(ID_Utilisateur),
    CHECK (LibelleRole IN ('utilisateur', 'admin'))
);

CREATE TABLE
    Comprend (
        ID_Trajet INTEGER,
        adresse_arret VARCHAR(50),
        PRIMARY KEY (ID_Trajet, adresse_arret),
        FOREIGN KEY (ID_Trajet) REFERENCES Trajet (ID_Trajet),
        FOREIGN KEY (adresse_arret) REFERENCES Arret (adresse_arret)
    );

CREATE TABLE Reserve (
    ID_Utilisateur INTEGER,
    ID_Trajet INTEGER,
    Statut_reservation VARCHAR(50),
    Date_Reservation DATE,
    Role_Utilisateur CHAR(10) DEFAULT 'passager', -- Désignation explicite du rôle
    PRIMARY KEY (ID_Utilisateur, ID_Trajet),
    FOREIGN KEY (ID_Utilisateur) REFERENCES Utilisateur(ID_Utilisateur),
    FOREIGN KEY (ID_Trajet) REFERENCES Trajet(ID_Trajet)
);
