<?php
session_start();
include '../db/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['additional_stops'] = [];
    foreach ($_POST['arrets'] as $arret) {
        $adresse_arret = isset($arret['adresse_arret']) ? pg_escape_string($dbconn, $arret['adresse_arret']) : '';
        $cp_ville = isset($arret['CP_ville']) ? pg_escape_string($dbconn, $arret['CP_ville']) : '';
        $details = isset($arret['Details']) ? pg_escape_string($dbconn, $arret['Details']) : '';

        $_SESSION['additional_stops'][] = [
            'adresse_arret' => $adresse_arret,
            'CP_ville' => $cp_ville,
            'Details' => $details,
        ];
    }

    header('Location: permis_info.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Publier un Trajet - Infos Arrêts</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css"> <!-- Add your custom styles -->
    <script>
        let stopIndex = 0; // Initialize stop index

        function addStop() {
            const stopsContainer = document.getElementById('stops-container');
            const stopTemplate = document.getElementById('stop-template').content.cloneNode(true);

            stopTemplate.querySelectorAll('.form-input').forEach(input => {
                input.name = input.name.replace('0', stopIndex); // Update input names with current stop index
            });

            stopsContainer.appendChild(stopTemplate);
            stopIndex++; // Increment stop index
        }

        function removeStop(event) {
            const stop = event.target.closest('.stop');
            stop.remove();
        }
    </script>
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Infos Arrêts</h2>
            </header>
            <form action="additional_stops.php" method="POST" class="field-set">
                <div id="stops-container"></div>
                <button class="submit-button" type="button" onclick="addStop()">Ajouter un arrêt</button><br>
                <button class="submit-button" type="submit">Suivant</button>
            </form>

            <template id="stop-template">
                <div class="stop">
                    <span class="input-item">
                        <i class="fa fa-address-card"></i>
                    </span>
                    <input class="form-input" type="text" name="arrets[0][adresse_arret]" placeholder="Adresse de l'Arrêt" required><br>

                    <span class="input-item">
                        <i class="fa fa-map-marker"></i>
                    </span>
                    <input class="form-input" type="number" name="arrets[0][CP_ville]" placeholder="Code Postal / Ville" required><br>

                    <span class="input-item">
                        <i class="fa fa-info-circle"></i>
                    </span>
                    <textarea class="form-input" name="arrets[0][Details]" placeholder="Détails" required></textarea><br>

                    <button class="submit-button" type="button" onclick="removeStop(event)">Supprimer cet arrêt</button>
                </div>
            </template>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
