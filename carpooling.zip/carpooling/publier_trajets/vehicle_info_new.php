<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['vehicle_info'] = [
        'marque' => $_POST['marque'],
        'modele' => $_POST['modele'],
        'annee' => $_POST['annee'],
        'couleur' => $_POST['couleur']
    ];
    header('Location: submit_trip.php'); // Redirect to finalize the trip
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un Véhicule</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Ajouter un Véhicule</h2>
            </header>
            <form action="vehicle_info_new.php" method="POST" class="field-set">
                <span class="input-item">
                    <i class="fa fa-car"></i>
                </span>
                <input class="form-input" name="marque" type="text" placeholder="Marque du Véhicule" required><br>
                
                <span class="input-item">
                    <i class="fa fa-car"></i>
                </span>
                <input class="form-input" name="modele" type="text" placeholder="Modèle du Véhicule" required><br>
                
                <span class="input-item">
                    <i class="fa fa-calendar"></i>
                </span>
                <input class="form-input" name="annee" type="date" placeholder="Année du Véhicule" required><br>
                
                <span class="input-item">
                    <i class="fa fa-paint-brush"></i>
                </span>
                <input class="form-input" name="couleur" type="text" placeholder="Couleur du Véhicule" required><br>
                
                <button class="submit-button" type="submit">Suivant</button>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
