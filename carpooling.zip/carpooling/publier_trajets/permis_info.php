<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['permis_info'] = [
        'numero_permis' => $_POST['numero_permis'],
        'date_expiration_permis' => $_POST['date_expiration_permis']
    ];
    header('Location: vehicle_info.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Publier un Trajet - Infos Permis</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));

            // Set default date to today
            const dateField = document.getElementById('date_expiration_permis');
            const today = new Date();
            const day = String(today.getDate()).padStart(2, '0');
            const month = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
            const year = today.getFullYear();
            const currentDate = `${year}-${month}-${day}`;
            dateField.value = currentDate;
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Infos Permis</h2>
            </header>
            <form action="permis_info.php" method="POST" class="field-set">
                <span class="input-item">
                    <i class="fa fa-id-card"></i>
                </span>
                <input class="form-input" type="text" id="numero_permis" name="numero_permis" placeholder="Numéro de Permis" required><br>

                <span class="input-item">
                    <i class="fa fa-calendar"></i>
                </span>
                <input class="form-input" type="date" id="date_expiration_permis" name="date_expiration_permis" required><br>

                <button class="submit-button" type="submit">Suivant</button>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
