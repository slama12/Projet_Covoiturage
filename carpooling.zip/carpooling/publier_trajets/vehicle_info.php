<?php
session_start();
include '../db/db_connect.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html"); // Redirect to login page if not logged in
    exit();
}

$id_utilisateur = $_SESSION['id_utilisateur'];

// Retrieve user's vehicle information from the Conduit table
$vehicle_query = "SELECT v.* FROM Vehicule v
                  JOIN Conduit c ON v.ID_Vehicule = c.ID_Vehicule
                  WHERE c.ID_Utilisateur = $1";
$vehicle_result = pg_query_params($dbconn, $vehicle_query, array($id_utilisateur));
$vehicles = pg_fetch_all($vehicle_result);

pg_close($dbconn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Infos Véhicule</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Infos Véhicule</h2>
            </header>
            <div id="vehicle-info">
                <h3>Véhicule</h3>
                <?php if (!empty($vehicles)): ?>
                    <ul>
                        <?php foreach ($vehicles as $vehicle): ?>
                            <li class="aff">
                                <p>Marque: <?= htmlspecialchars($vehicle['marque']) ?></p>
                                <p>Modèle: <?= htmlspecialchars($vehicle['modele']) ?></p>
                                <p>Année: <?= htmlspecialchars($vehicle['annee']) ?></p>
                                <p>Couleur: <?= htmlspecialchars($vehicle['couleur']) ?></p>
                                <form action="submit_vehicle_choice.php" method="POST">
                                    <input type="hidden" name="vehicle_id" value="<?= htmlspecialchars($vehicle['id_vehicule']) ?>">
                                    <button class="submit-button" type="submit" name="use_existing_vehicle">Utiliser ce véhicule</button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>Vous n'avez enregistré aucun véhicule.</p>
                <?php endif; ?>
                <form action="submit_vehicle_choice.php" method="POST">
                    <button class="submit-button" type="submit" name="add_new_vehicle">Ajouter un nouveau véhicule</button>
                </form>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
