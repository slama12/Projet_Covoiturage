<?php
session_start();
include '../db/db_connect.php'; // Adjust the path as needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Save address information in the session
    $_SESSION['address_info'] = [
        'depart' => [
            'adresse_arret' => pg_escape_string($dbconn, $_POST['depart_adresse_arret']),
            'CP_ville' => pg_escape_string($dbconn, $_POST['depart_CP_ville']),
            'Details' => pg_escape_string($dbconn, $_POST['depart_Details'])
        ],
        'destination' => [
            'adresse_arret' => pg_escape_string($dbconn, $_POST['destination_adresse_arret']),
            'CP_ville' => pg_escape_string($dbconn, $_POST['destination_CP_ville']),
            'Details' => pg_escape_string($dbconn, $_POST['destination_Details'])
        ]
    ];
    header('Location: additional_stops.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Publier un Trajet - Adresses</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css"> <!-- Add your custom styles -->
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Adresses de Départ et de Destination</h2>
            </header>
            <form action="enter_addresses.php" method="POST" class="field-set">
                <h3>Départ</h3>
                <span class="input-item">
                    <i class="fa fa-address-card"></i>
                </span>
                <input class="form-input" type="text" id="depart_adresse_arret" name="depart_adresse_arret" placeholder="Adresse de Départ" required><br>

                <span class="input-item">
                    <i class="fa fa-map-marker"></i>
                </span>
                <input class="form-input" type="text" id="depart_CP_ville" name="depart_CP_ville" placeholder="Code Postal / Ville" required><br>

                <span class="input-item">
                    <i class="fa fa-info-circle"></i>
                </span>
                <textarea class="form-input" id="depart_Details" name="depart_Details" placeholder="Détails" required></textarea><br>

                <h3>Destination</h3>
                <span class="input-item">
                    <i class="fa fa-address-card"></i>
                </span>
                <input class="form-input" type="text" id="destination_adresse_arret" name="destination_adresse_arret" placeholder="Adresse de Destination" required><br>

                <span class="input-item">
                    <i class="fa fa-map-marker"></i>
                </span>
                <input class="form-input" type="text" id="destination_CP_ville" name="destination_CP_ville" placeholder="Code Postal / Ville" required><br>

                <span class="input-item">
                    <i class="fa fa-info-circle"></i>
                </span>
                <textarea class="form-input" id="destination_Details" name="destination_Details" placeholder="Détails" required></textarea><br>

                <button class="submit-button" type="submit">Suivant</button>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
