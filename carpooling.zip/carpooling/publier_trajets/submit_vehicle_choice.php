<?php
session_start();

if (isset($_POST['use_existing_vehicle'])) {
    $_SESSION['vehicle_choice'] = 'existing';
    $_SESSION['vehicle_info'] = ['id_vehicule' => $_POST['vehicle_id']];
    header('Location: submit_trip.php'); // Redirect to finalize the trip
    exit();
} elseif (isset($_POST['add_new_vehicle'])) {
    $_SESSION['vehicle_choice'] = 'new';
    header('Location: vehicle_info_new.php'); // Redirect to add new vehicle info
    exit();
} else {
    echo "Invalid action.";
    exit();
}
?>

