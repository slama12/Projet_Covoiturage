<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['trip_info'] = [
        'ville_depart' => $_POST['ville_depart'],
        'ville_destination' => $_POST['ville_destination'],
        'date_trajet' => $_POST['date_trajet'],
        'heure_depart' => $_POST['heure_depart'],
        'places_disponibles' => $_POST['places_disponibles']
    ];
    header('Location: enter_addresses.php'); // Redirect to the new address entry page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Publier un Trajet - Infos Trajet</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css"> <!-- Add your custom styles -->
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function () {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));

            // Set current date and time
            const now = new Date();
            document.getElementById('date_trajet').value = now.toISOString().substring(0, 10);
            document.getElementById('heure_depart').value = now.toTimeString().substring(0, 5);

            // Set the number of places
            document.getElementById('places_disponibles').min = 1;
            document.getElementById('places_disponibles').max = 4;
            document.getElementById('places_disponibles').value = 1;
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Infos Trajet</h2>
            </header>
            <form action="trip_info.php" method="POST" class="field-set">
                <span class="input-item">
                    <i class="fa fa-map-marker-alt"></i>
                </span>
                <input class="form-input" type="text" id="ville_depart" name="ville_depart" placeholder="Ville de Départ" required><br>

                <span class="input-item">
                    <i class="fa fa-map-marker-alt"></i>
                </span>
                <input class="form-input" type="text" id="ville_destination" name="ville_destination" placeholder="Ville de Destination" required><br>

                <span class="input-item">
                    <i class="fa fa-calendar-alt"></i>
                </span>
                <input class="form-input" type="date" id="date_trajet" name="date_trajet" required><br>

                <span class="input-item">
                    <i class="fa fa-clock"></i>
                </span>
                <input class="form-input" type="time" id="heure_depart" name="heure_depart" required><br>

                <span class="input-item">
                    <i class="fa fa-users"></i>
                </span>
                <input class="form-input" type="number" id="places_disponibles" name="places_disponibles" placeholder="Places Disponibles" required><br>

                <button class="submit-button" type="submit">Suivant</button>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>