<?php
session_start();
include '../db/db_connect.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../avant connection/connexion.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST["submit"]))) {
    $user_id = $_SESSION['id_utilisateur'];
    $trip_info = $_SESSION['trip_info'] ?? null;
    $permis_info = $_SESSION['permis_info'] ?? null;
    $vehicle_info = $_SESSION['vehicle_info'] ?? null;
    $additional_stops = $_SESSION['additional_stops'] ?? [];
    $address_info = $_SESSION['address_info'] ?? null;

    if (!$trip_info || !$permis_info || !$address_info) {
        echo "Les variables de session ne sont pas correctement définies.";
        exit();
    }

    // Begin transaction
    pg_query($dbconn, "BEGIN");

    // Insert the trip details
    $trajet_query = "INSERT INTO Trajet (heure_depart, date_ajout, Date_trajet, Places_disponibles, Ville_depart, Ville_destination, ID_Utilisateur, Numero_Permis, Date_Expiration_Permis) 
                     VALUES ($1, CURRENT_TIMESTAMP, $2, $3, $4, $5, $6, $7, $8) RETURNING ID_Trajet";
    $trajet_result = pg_query_params($dbconn, $trajet_query, array(
        $trip_info['heure_depart'],
        $trip_info['date_trajet'],
        $trip_info['places_disponibles'],
        $trip_info['ville_depart'],
        $trip_info['ville_destination'],
        $user_id,
        $permis_info['numero_permis'],
        $permis_info['date_expiration_permis']
    ));

    if ($trajet_result) {
        $row = pg_fetch_assoc($trajet_result);
        $trajet_id = $row['id_trajet'];

        if ($_SESSION['vehicle_choice'] == 'existing' && !empty($vehicle_info['id_vehicule'])) {
            // Use existing vehicle
            $vehicule_id = $vehicle_info['id_vehicule'];
        } else {
            // Insert new vehicle details
            $vehicule_query = "INSERT INTO Vehicule (Marque, Modele, Annee, Couleur) 
                               VALUES ($1, $2, $3, $4) RETURNING ID_Vehicule";
            $vehicule_result = pg_query_params($dbconn, $vehicule_query, array($vehicle_info['marque'], $vehicle_info['modele'], $vehicle_info['annee'], $vehicle_info['couleur']));

            if ($vehicule_result) {
                $row = pg_fetch_assoc($vehicule_result);
                $vehicule_id = $row['id_vehicule'];

                // Insert into Conduit table
                $conduit_query = "INSERT INTO Conduit (ID_Utilisateur, ID_Vehicule, Role_Utilisateur) VALUES ($1, $2, 'conducteur')";
                $conduit_result = pg_query_params($dbconn, $conduit_query, array($user_id, $vehicule_id));

                if (!$conduit_result) {
                    // Rollback transaction
                    pg_query($dbconn, "ROLLBACK");
                    echo "Erreur lors de l'insertion dans la table Conduit: " . pg_last_error($dbconn);
                    exit();
                }
            } else {
                // Rollback transaction
                pg_query($dbconn, "ROLLBACK");
                echo "Erreur lors de l'insertion des détails du véhicule: " . pg_last_error($dbconn);
                exit();
            }
        }

        // Update the trip with the vehicle ID
        $update_trajet_query = "UPDATE Trajet SET ID_Vehicule = $1 WHERE ID_Trajet = $2";
        pg_query_params($dbconn, $update_trajet_query, array($vehicule_id, $trajet_id));

        // Insert stops (initial, additional, and destination)
        $stops = [
            [
                'adresse_arret' => $address_info['depart']['adresse_arret'],
                'CP_ville' => $address_info['depart']['CP_ville'],
                'Details' => $address_info['depart']['Details'],
                'num_Arret' => 1
            ]
        ];

        foreach ($additional_stops as $index => $stop) {
            // Ensure CP_ville and Details are set and valid
            $stop['CP_ville'] = !empty($stop['CP_ville']) ? (int)$stop['CP_ville'] : null;
            $stop['Details'] = !empty($stop['Details']) ? $stop['Details'] : 'No details provided';
            $stop['num_Arret'] = $index + 2; // Assigning num_Arret to additional stops
            $stops[] = $stop;
        }

        $stops[] = [
            'adresse_arret' => $address_info['destination']['adresse_arret'],
            'CP_ville' => $address_info['destination']['CP_ville'],
            'Details' => $address_info['destination']['Details'],
            'num_Arret' => count($additional_stops) + 2
        ];

        foreach ($stops as $stop) {
            if (!empty($stop['adresse_arret'])) {
                $stop_query = "INSERT INTO Arret (adresse_arret, CP_ville, num_Arret, Details) 
                               VALUES ($1, $2, $3, $4) ON CONFLICT (adresse_arret) DO UPDATE SET CP_ville = EXCLUDED.CP_ville, Details = EXCLUDED.Details, num_Arret = EXCLUDED.num_Arret RETURNING adresse_arret";
                $stop_result = pg_query_params($dbconn, $stop_query, array($stop['adresse_arret'], $stop['CP_ville'], $stop['num_Arret'], $stop['Details']));

                if ($stop_result) {
                    $stop_row = pg_fetch_assoc($stop_result);
                    $adresse_arret = $stop_row['adresse_arret'];

                    $comprend_query = "INSERT INTO Comprend (ID_Trajet, adresse_arret) VALUES ($1, $2)";
                    pg_query_params($dbconn, $comprend_query, array($trajet_id, $adresse_arret));
                } else {
                    // Rollback transaction
                    pg_query($dbconn, "ROLLBACK");
                    echo "Erreur lors de l'insertion des arrêts: " . pg_last_error($dbconn);
                    exit();
                }
            }
        }

        // Commit transaction
        pg_query($dbconn, "COMMIT");
        echo "Trajet publié avec succès!";
        header("Location: ../apres connection/HomeAfter.php");
        exit();
    } else {
        // Rollback transaction
        pg_query($dbconn, "ROLLBACK");
        echo "Erreur lors de l'insertion du trajet: " . pg_last_error($dbconn);
    }

    pg_close($dbconn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Publier un Trajet</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../template/menu.css">
    <link rel="stylesheet" href="../template/style.css">
</head>
<body>
    <div id="menu-container"></div>
    <script>
        window.onload = function() {
            fetch('../template/menuAfter.php')
                .then(response => response.text())
                .then(html => {
                    document.getElementById('menu-container').innerHTML = html;
                })
                .catch(error => console.error('Error loading the menu:', error));
        };
    </script>

    <div class="overlay">
        <div class="con">
            <header class="head-form">
                <h2>Finaliser le Trajet</h2>
            </header>
            <form action="submit_trip.php" method="POST" class="field-set">
                <button class="submit-button" type="submit" name="submit">Publier le Trajet</button>
            </form>
        </div>
    </div>
</body>
</html>
