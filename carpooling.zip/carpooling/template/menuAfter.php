<?php
session_start();

if (!isset($_SESSION['prenom'])) {
    header('Location: connexion.html');
    exit();
}

?>
<nav>
    <div class="wrapper">
        <div class="logo"><a href='../apres connection/HomeAfter.php'>Covoiturage</a></div>
        <input type="radio" name="slider" id="menu-btn">
        <input type="radio" name="slider" id="close-btn">

        <ul class="nav-links">
            <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>

            <li><a href="#"><i class="fas fa-info-circle"></i> Nous</a></li>
            <li><a href='../rechercher_trajets/recherche_trajet.php'><i class="fas fa-search"></i> Rechercher</a></li>
            <li><a href='../publier_trajets/trip_info.php'><i class="fas fa-road"></i> Publier un trajet</a></li>
            <li class="profile-menu">
                <a href="#" class="desktop-item"><i class="fa fa-user-circle"></i><?php echo " " . htmlspecialchars($_SESSION['prenom']); ?></a>
                <input type="checkbox" id="showDrop">
                <label for="showDrop" class="mobile-item"><i class="fa fa-user-circle"></i><?php echo " " . htmlspecialchars($_SESSION['prenom']); ?></label>
                <ul class="drop-menu">
                    <li><a href='../apres connection/profile.php'><i class="fas fa-user"></i> Profile</a></li>
                    <li><a href='../messages/messages.php'><i class="fas fa-envelope"></i> Messages </a></li>
                    <li><a href='../apres connection/avis.php'><i class="fas fa-envelope"></i> Avis </a></li>
                    <li><a href='../apres connection/trajets.php'><i class="fas fa-car"></i> Trajets </a></li>
                    <li><a href='../apres connection/deconnexion.php'><i class="fas fa-sign-out-alt"></i> Déconnexion</a></li>
                </ul>
            </li>
        </ul>
        <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
    </div>
</nav>
